<?php

declare(strict_types=1);

/**
 * Installer / migration + seeder for Doggu Hoteru POS.
 *
 * Run from the browser (http://localhost/printerthermal/dogguhoteru/install.php)
 * or CLI (php install.php). Creates the SQLite schema and fills it with sample
 * IDR data. Pass ?fresh=1 (or --fresh) to drop and rebuild everything.
 */

require __DIR__ . '/config/config.php';
require __DIR__ . '/app/Database.php';
require __DIR__ . '/app/helpers.php';

$fresh = isset($_GET['fresh']) || in_array('--fresh', $argv ?? [], true);
$isCli = PHP_SAPI === 'cli';
$nl = $isCli ? "\n" : "<br>\n";

function out(string $msg): void
{
    global $nl;
    echo $msg . $nl;
    if (PHP_SAPI !== 'cli') {
        flush();
    }
}

if (!$isCli) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<pre style="font:14px/1.5 monospace;background:#0f172a;color:#e2e8f0;padding:20px;">';
}

try {
    $pdo = Database::conn();

    if ($fresh) {
        out('Dropping existing tables...');
        $tables = ['logs', 'payments', 'transaction_items', 'transactions', 'groomings',
                   'boardings', 'pets', 'customers', 'services', 'rooms', 'staff', 'settings'];
        foreach ($tables as $t) {
            $pdo->exec("DROP TABLE IF EXISTS $t");
        }
    }

    out('Creating schema...');
    $pdo->exec(<<<'SQL'
    CREATE TABLE IF NOT EXISTS settings (
        key   TEXT PRIMARY KEY,
        value TEXT
    );

    CREATE TABLE IF NOT EXISTS staff (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        username      TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        name          TEXT NOT NULL,
        role          TEXT NOT NULL DEFAULT 'cashier',
        active        INTEGER NOT NULL DEFAULT 1,
        created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS customers (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        code       TEXT UNIQUE,
        name       TEXT NOT NULL,
        phone      TEXT,
        email      TEXT,
        address    TEXT,
        notes      TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS pets (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id  INTEGER NOT NULL,
        name         TEXT NOT NULL,
        species      TEXT DEFAULT 'Dog',
        breed        TEXT,
        gender       TEXT,
        weight       REAL,
        birthday     TEXT,
        temperament  TEXT,
        vaccination  TEXT,
        notes        TEXT,
        photo        TEXT,
        created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS services (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        code        TEXT UNIQUE,
        name        TEXT NOT NULL,
        category    TEXT NOT NULL DEFAULT 'Grooming',
        price       INTEGER NOT NULL DEFAULT 0,
        unit        TEXT DEFAULT 'pcs',
        description TEXT,
        active      INTEGER NOT NULL DEFAULT 1,
        created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS rooms (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        name        TEXT NOT NULL,
        type        TEXT DEFAULT 'Standard',
        daily_price INTEGER NOT NULL DEFAULT 0,
        status      TEXT NOT NULL DEFAULT 'available',
        notes       TEXT
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_no     TEXT NOT NULL UNIQUE,
        customer_id    INTEGER,
        pet_id         INTEGER,
        staff_id       INTEGER,
        subtotal       INTEGER NOT NULL DEFAULT 0,
        discount       INTEGER NOT NULL DEFAULT 0,
        tax            INTEGER NOT NULL DEFAULT 0,
        total          INTEGER NOT NULL DEFAULT 0,
        paid           INTEGER NOT NULL DEFAULT 0,
        change         INTEGER NOT NULL DEFAULT 0,
        payment_method TEXT DEFAULT 'cash',
        status         TEXT NOT NULL DEFAULT 'paid',
        notes          TEXT,
        created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
        FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE SET NULL,
        FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS transaction_items (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL,
        service_id     INTEGER,
        description    TEXT NOT NULL,
        qty            INTEGER NOT NULL DEFAULT 1,
        price          INTEGER NOT NULL DEFAULT 0,
        line_total     INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS payments (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL,
        amount         INTEGER NOT NULL DEFAULT 0,
        method         TEXT DEFAULT 'cash',
        created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS boardings (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        pet_id      INTEGER NOT NULL,
        room_id     INTEGER,
        check_in    TEXT NOT NULL,
        check_out   TEXT,
        daily_price INTEGER NOT NULL DEFAULT 0,
        days        INTEGER NOT NULL DEFAULT 1,
        total       INTEGER NOT NULL DEFAULT 0,
        status      TEXT NOT NULL DEFAULT 'checked_in',
        notes       TEXT,
        created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
        FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
        FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS groomings (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id    INTEGER NOT NULL,
        pet_id         INTEGER NOT NULL,
        groomer        TEXT,
        appointment_at TEXT NOT NULL,
        service        TEXT,
        checklist      TEXT,
        status         TEXT NOT NULL DEFAULT 'scheduled',
        notes          TEXT,
        before_photo   TEXT,
        after_photo    TEXT,
        created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
        FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS logs (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        level      TEXT NOT NULL DEFAULT 'info',
        message    TEXT NOT NULL,
        context    TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    );

    CREATE INDEX IF NOT EXISTS idx_pets_customer ON pets(customer_id);
    CREATE INDEX IF NOT EXISTS idx_items_trx ON transaction_items(transaction_id);
    CREATE INDEX IF NOT EXISTS idx_trx_created ON transactions(created_at);
    SQL);

    out('Schema ready.');

    // ---------------------------------------------------------------
    // Seed only when empty (or after a fresh rebuild).
    // ---------------------------------------------------------------
    $hasStaff = (int) Database::scalar('SELECT COUNT(*) FROM staff') > 0;
    if ($hasStaff && !$fresh) {
        out('Data already present - skipping seed. Use install.php?fresh=1 to rebuild.');
    } else {
        out('Seeding sample data (IDR)...');
        seedAll();
        out('Seed complete.');
    }

    out('');
    out('==================================================');
    out('  Doggu Hoteru POS installed successfully.');
    out('  Login: admin / admin123   (also: kasir / kasir123)');
    out('  Open:  index.php');
    out('==================================================');
} catch (Throwable $e) {
    out('ERROR: ' . $e->getMessage());
    out($e->getTraceAsString());
}

if (!$isCli) {
    echo '</pre>';
    echo '<p style="font:14px monospace;"><a href="index.php" style="color:#22c55e">&raquo; Go to POS</a></p>';
}

// ===================================================================
//  Seed routines
// ===================================================================
function seedAll(): void
{
    // ---- Settings ----
    $settings = [
        'business_name'    => 'Doggu Hoteru',
        'business_address' => 'Jl. Sunset Road No. 88, Kuta, Bali',
        'business_phone'   => '0361-778899',
        'business_email'   => 'halo@dogguhoteru.id',
        'currency'         => 'IDR',
        'tax_rate'         => (string) DEFAULT_TAX_RATE,
        'tax_enabled'      => '1',
        'printer_name'     => PRINTER_NAME,
        'printer_width'    => (string) PRINTER_WIDTH,
        'receipt_footer'   => 'Terima kasih! Sampai jumpa lagi ^_^',
        'timezone'         => APP_TIMEZONE,
    ];
    foreach ($settings as $k => $v) {
        Database::run(
            'INSERT INTO settings (key, value) VALUES (?, ?)
             ON CONFLICT(key) DO UPDATE SET value = excluded.value',
            [$k, $v]
        );
    }

    // ---- Staff ----
    Database::insert('staff', [
        'username' => 'admin', 'name' => 'Administrator', 'role' => 'admin',
        'password_hash' => password_hash('admin123', PASSWORD_DEFAULT), 'active' => 1,
    ]);
    Database::insert('staff', [
        'username' => 'kasir', 'name' => 'Putu Kasir', 'role' => 'cashier',
        'password_hash' => password_hash('kasir123', PASSWORD_DEFAULT), 'active' => 1,
    ]);
    $groomer = Database::insert('staff', [
        'username' => 'groomer', 'name' => 'Kadek Groomer', 'role' => 'groomer',
        'password_hash' => password_hash('groomer123', PASSWORD_DEFAULT), 'active' => 1,
    ]);

    // ---- Services (IDR) ----
    $services = [
        ['BRD-STD', 'Penitipan Standard',   'Boarding',    120000, 'hari'],
        ['BRD-DLX', 'Penitipan Deluxe',      'Boarding',    200000, 'hari'],
        ['BRD-VIP', 'Penitipan VIP Suite',   'Boarding',    350000, 'hari'],
        ['GRM-BSC', 'Grooming Basic',        'Grooming',     85000, 'ekor'],
        ['GRM-FULL','Grooming Full Package', 'Grooming',    150000, 'ekor'],
        ['BTH-STD', 'Mandi Standard',        'Bath',         60000, 'ekor'],
        ['BTH-MED', 'Mandi Medicated',       'Bath',         95000, 'ekor'],
        ['SPA-AROM','Spa Aromatherapy',      'Spa',         175000, 'ekor'],
        ['MED-VAC', 'Vaksinasi',             'Medicine',    250000, 'dosis'],
        ['MED-CHK', 'Pemeriksaan Dokter',    'Medicine',    100000, 'kali'],
        ['TRP-ANT', 'Antar Jemput',          'Transport',    50000, 'trip'],
        ['ACC-FOOD','Makanan Premium 1kg',   'Accessories',  85000, 'pcs'],
        ['ACC-TOY', 'Mainan Anjing',         'Accessories',  45000, 'pcs'],
        ['ACC-SHMP','Shampoo Anti Kutu',     'Accessories',  65000, 'botol'],
    ];
    foreach ($services as $s) {
        Database::insert('services', [
            'code' => $s[0], 'name' => $s[1], 'category' => $s[2],
            'price' => $s[3], 'unit' => $s[4], 'active' => 1,
        ]);
    }

    // ---- Rooms ----
    $rooms = [
        ['Kandang A1', 'Standard', 120000],
        ['Kandang A2', 'Standard', 120000],
        ['Kandang B1', 'Deluxe',   200000],
        ['Kandang B2', 'Deluxe',   200000],
        ['Suite VIP 1','VIP',      350000],
        ['Suite VIP 2','VIP',      350000],
    ];
    foreach ($rooms as $r) {
        Database::insert('rooms', [
            'name' => $r[0], 'type' => $r[1], 'daily_price' => $r[2], 'status' => 'available',
        ]);
    }

    // ---- Customers + Pets ----
    $customers = [
        ['CUST-0001', 'Wayan Sukarta', '081234567001', 'wayan@mail.com', 'Denpasar, Bali',
            [['Bruno', 'Dog', 'Golden Retriever', 'Male', 28.5, 'Ramah'],
             ['Coco',  'Dog', 'Pomeranian',       'Female', 3.2, 'Aktif']]],
        ['CUST-0002', 'Made Ayu', '081234567002', 'ayu@mail.com', 'Ubud, Gianyar',
            [['Milo',  'Cat', 'Persian', 'Male', 4.5, 'Pemalu']]],
        ['CUST-0003', 'Ketut Wirawan', '081234567003', 'ketut@mail.com', 'Sanur, Denpasar',
            [['Rocky', 'Dog', 'Bulldog', 'Male', 22.0, 'Tenang'],
             ['Luna',  'Dog', 'Beagle',  'Female', 11.0, 'Ramah']]],
        ['CUST-0004', 'Nyoman Sari', '081234567004', 'sari@mail.com', 'Kuta, Badung',
            [['Snowy', 'Dog', 'Samoyed', 'Female', 20.0, 'Ceria']]],
        ['CUST-0005', 'Gede Prana', '081234567005', 'gede@mail.com', 'Tabanan, Bali',
            [['Max',   'Dog', 'German Shepherd', 'Male', 32.0, 'Waspada']]],
    ];

    $custIds = [];
    $petIds = [];
    foreach ($customers as $c) {
        $cid = Database::insert('customers', [
            'code' => $c[0], 'name' => $c[1], 'phone' => $c[2],
            'email' => $c[3], 'address' => $c[4],
        ]);
        $custIds[] = $cid;
        foreach ($c[5] as $p) {
            $pid = Database::insert('pets', [
                'customer_id' => $cid, 'name' => $p[0], 'species' => $p[1],
                'breed' => $p[2], 'gender' => $p[3], 'weight' => $p[4],
                'temperament' => $p[5], 'vaccination' => 'Rabies 2025',
            ]);
            $petIds[$cid][] = $pid;
        }
    }

    // ---- Sample transactions across the last ~20 days ----
    $svc = Database::all('SELECT * FROM services');
    $svcById = [];
    foreach ($svc as $s) {
        $svcById[(int) $s['id']] = $s;
    }
    $taxRate = (int) DEFAULT_TAX_RATE;

    $samples = [
        [1, [4 => 1, 6 => 1], 0],           // Wayan: grooming basic + mandi
        [2, [8 => 1], 10],                   // Made: spa, 10% discount
        [3, [5 => 2], 0],                    // Ketut: 2x grooming full
        [4, [1 => 3], 0],                    // Nyoman: boarding 3 hari
        [5, [9 => 1, 10 => 1], 0],           // Gede: vaksinasi + periksa
        [1, [12 => 2, 13 => 1], 5],          // Wayan: makanan + mainan
        [3, [7 => 1, 14 => 1], 0],           // Ketut: mandi medicated + shampoo
        [2, [4 => 1], 0],                    // Made: grooming basic
    ];

    $methods = ['cash', 'cash', 'qris', 'debit', 'cash', 'qris', 'cash', 'debit'];

    foreach ($samples as $i => $sample) {
        [$custIdx, $lines, $discPct] = $sample;
        $cid = $custIds[$custIdx - 1];
        $pid = $petIds[$cid][0] ?? null;
        $daysAgo = (7 - $i) * 2 + 1;
        $when = date('Y-m-d H:i:s', strtotime("-$daysAgo days +" . (9 + $i) . " hours"));

        Database::begin();
        try {
            $subtotal = 0;
            $itemsData = [];
            foreach ($lines as $svcId => $qty) {
                $s = $svcById[$svcId];
                $price = (int) $s['price'];
                $lt = $price * $qty;
                $subtotal += $lt;
                $itemsData[] = [
                    'service_id' => $svcId, 'description' => $s['name'],
                    'qty' => $qty, 'price' => $price, 'line_total' => $lt,
                ];
            }
            $discount = (int) round($subtotal * $discPct / 100);
            $taxable = $subtotal - $discount;
            $tax = (int) round($taxable * $taxRate / 100);
            $total = $taxable + $tax;
            $paid = (int) (ceil($total / 10000) * 10000);
            $change = $paid - $total;

            $invoiceNo = 'INV-' . date('Ymd', strtotime($when)) . '-' . str_pad((string) ($i + 1), 4, '0', STR_PAD_LEFT);

            $tid = Database::insert('transactions', [
                'invoice_no' => $invoiceNo, 'customer_id' => $cid, 'pet_id' => $pid,
                'staff_id' => 2, 'subtotal' => $subtotal, 'discount' => $discount,
                'tax' => $tax, 'total' => $total, 'paid' => $paid, 'change' => $change,
                'payment_method' => $methods[$i], 'status' => 'paid',
                'created_at' => $when,
            ]);
            foreach ($itemsData as $it) {
                $it['transaction_id'] = $tid;
                Database::insert('transaction_items', $it);
            }
            Database::insert('payments', [
                'transaction_id' => $tid, 'amount' => $paid,
                'method' => $methods[$i], 'created_at' => $when,
            ]);
            Database::commit();
        } catch (Throwable $e) {
            Database::rollback();
            throw $e;
        }
    }

    // ---- Sample boardings ----
    $roomIds = array_map(fn ($r) => (int) $r['id'], Database::all('SELECT id FROM rooms'));
    // active check-in
    $bIn = date('Y-m-d H:i:s', strtotime('-2 days +10 hours'));
    Database::insert('boardings', [
        'customer_id' => $custIds[3], 'pet_id' => $petIds[$custIds[3]][0],
        'room_id' => $roomIds[0], 'check_in' => $bIn, 'daily_price' => 120000,
        'days' => 1, 'total' => 0, 'status' => 'checked_in', 'notes' => 'Alergi makanan ayam',
    ]);
    Database::update('rooms', ['status' => 'occupied'], ['id' => $roomIds[0]]);
    // completed boarding
    Database::insert('boardings', [
        'customer_id' => $custIds[0], 'pet_id' => $petIds[$custIds[0]][0],
        'room_id' => $roomIds[2], 'check_in' => date('Y-m-d H:i:s', strtotime('-10 days')),
        'check_out' => date('Y-m-d H:i:s', strtotime('-7 days')), 'daily_price' => 200000,
        'days' => 3, 'total' => 600000, 'status' => 'checked_out',
    ]);

    // ---- Sample groomings ----
    Database::insert('groomings', [
        'customer_id' => $custIds[0], 'pet_id' => $petIds[$custIds[0]][1] ?? $petIds[$custIds[0]][0],
        'groomer' => 'Kadek Groomer', 'appointment_at' => date('Y-m-d H:i:s', strtotime('+1 day +10 hours')),
        'service' => 'Grooming Full Package', 'status' => 'scheduled',
        'checklist' => json_encode(['Potong kuku', 'Bersih telinga', 'Potong bulu', 'Mandi']),
    ]);
    Database::insert('groomings', [
        'customer_id' => $custIds[2], 'pet_id' => $petIds[$custIds[2]][0],
        'groomer' => 'Kadek Groomer', 'appointment_at' => date('Y-m-d H:i:s', strtotime('-1 day +14 hours')),
        'service' => 'Grooming Basic', 'status' => 'completed',
        'checklist' => json_encode(['Potong kuku', 'Mandi']),
    ]);
}
