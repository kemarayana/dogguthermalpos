/* Doggu Hoteru POS - shared UI helpers */
(function () {
    'use strict';

    // Live clock in the topbar
    const clock = document.getElementById('clock');
    if (clock) {
        const tick = () => {
            const now = new Date();
            clock.textContent = now.toLocaleString('id-ID', {
                weekday: 'short', day: '2-digit', month: 'short',
                hour: '2-digit', minute: '2-digit', second: '2-digit'
            });
        };
        tick();
        setInterval(tick, 1000);
    }

    // Generic modal open/close (data-modal-open="id", data-modal-close)
    document.addEventListener('click', (e) => {
        const opener = e.target.closest('[data-modal-open]');
        if (opener) {
            const m = document.getElementById(opener.dataset.modalOpen);
            if (m) m.classList.add('open');
        }
        if (e.target.closest('[data-modal-close]') ||
            (e.target.classList.contains('modal-overlay'))) {
            const overlay = e.target.closest('.modal-overlay');
            if (overlay) overlay.classList.remove('open');
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
        }
    });

    // Confirm before delete forms
    document.querySelectorAll('form[data-confirm]').forEach(f => {
        f.addEventListener('submit', (e) => {
            if (!confirm(f.dataset.confirm)) e.preventDefault();
        });
    });

    // Format currency helper (Rupiah)
    window.formatIDR = function (n) {
        return 'Rp ' + Math.round(n).toLocaleString('id-ID');
    };
})();
