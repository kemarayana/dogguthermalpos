/* Doggu Hoteru POS - cashier screen logic */
(function () {
    'use strict';
    const cfg = window.POS_CONFIG || {};
    const $ = (id) => document.getElementById(id);
    const fmt = (n) => 'Rp ' + Math.round(n).toLocaleString('id-ID');

    let cart = [];              // {service_id, name, price, qty}
    let customer = null;        // {id, name}
    const state = { taxRate: parseFloat(cfg.taxRate) || 0 };

    // ---------------- Cart ----------------
    function addItem(serviceId, name, price) {
        const existing = cart.find(i => i.service_id === serviceId);
        if (existing) {
            existing.qty += 1;
        } else {
            cart.push({ service_id: serviceId, name, price: Number(price), qty: 1 });
        }
        renderCart();
    }

    function renderCart() {
        const box = $('cartItems');
        if (cart.length === 0) {
            box.innerHTML = '<div class="pos-empty" id="cartEmpty">Belum ada item. Pilih layanan di sebelah kiri.</div>';
        } else {
            box.innerHTML = cart.map((it, idx) => `
                <div class="cart-line">
                    <div class="nm">${escapeHtml(it.name)}<small>${fmt(it.price)}</small></div>
                    <div class="qty-ctrl">
                        <button type="button" data-act="dec" data-i="${idx}">&minus;</button>
                        <input type="number" min="1" value="${it.qty}" data-act="qty" data-i="${idx}">
                        <button type="button" data-act="inc" data-i="${idx}">+</button>
                    </div>
                    <div class="lt">${fmt(it.price * it.qty)}</div>
                    <button type="button" class="rm" data-act="rm" data-i="${idx}">&times;</button>
                </div>`).join('');
        }
        recalc();
    }

    function recalc() {
        const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
        let discount = parseInt($('discountInput').value) || 0;
        if (discount > subtotal) { discount = subtotal; $('discountInput').value = subtotal; }
        const taxable = subtotal - discount;
        const tax = $('taxToggle').checked ? Math.round(taxable * state.taxRate / 100) : 0;
        const total = taxable + tax;
        const paid = parseInt($('paidInput').value) || 0;
        const change = Math.max(0, paid - total);

        $('subtotalTxt').textContent = fmt(subtotal);
        $('taxTxt').textContent = fmt(tax);
        $('totalTxt').textContent = fmt(total);
        $('changeTxt').textContent = fmt(change);

        const canSave = cart.length > 0;
        $('saveSaleBtn').disabled = !canSave;
        $('saveOnlyBtn').disabled = !canSave;
        return { subtotal, discount, tax, total, paid, change };
    }

    // Cart interactions (delegated)
    $('cartItems').addEventListener('click', (e) => {
        const btn = e.target.closest('[data-act]');
        if (!btn) return;
        const i = parseInt(btn.dataset.i);
        const act = btn.dataset.act;
        if (act === 'inc') cart[i].qty++;
        else if (act === 'dec') cart[i].qty = Math.max(1, cart[i].qty - 1);
        else if (act === 'rm') cart.splice(i, 1);
        renderCart();
    });
    $('cartItems').addEventListener('change', (e) => {
        const inp = e.target.closest('[data-act="qty"]');
        if (!inp) return;
        cart[parseInt(inp.dataset.i)].qty = Math.max(1, parseInt(inp.value) || 1);
        renderCart();
    });

    $('clearCart').addEventListener('click', () => { cart = []; renderCart(); });
    $('discountInput').addEventListener('input', recalc);
    $('taxToggle').addEventListener('change', recalc);
    $('paidInput').addEventListener('input', recalc);

    // ---------------- Service tiles ----------------
    document.querySelectorAll('.service-tile').forEach(tile => {
        tile.addEventListener('click', () => {
            addItem(parseInt(tile.dataset.id), tile.dataset.name, tile.dataset.price);
        });
    });

    // Category filter
    document.querySelectorAll('.cat-filter').forEach(b => {
        b.addEventListener('click', () => {
            document.querySelectorAll('.cat-filter').forEach(x => x.classList.remove('active'));
            b.classList.add('active');
            const cat = b.dataset.cat;
            document.querySelectorAll('.service-tile').forEach(t => {
                t.style.display = (!cat || t.dataset.cat === cat) ? '' : 'none';
            });
        });
    });

    // Service text filter
    $('svcSearch').addEventListener('input', (e) => {
        const q = e.target.value.toLowerCase();
        document.querySelectorAll('.service-tile').forEach(t => {
            t.style.display = t.dataset.name.toLowerCase().includes(q) ? '' : 'none';
        });
    });

    // ---------------- Customer autocomplete ----------------
    let acTimer = null;
    $('custSearch').addEventListener('input', (e) => {
        clearTimeout(acTimer);
        const q = e.target.value.trim();
        if (q.length < 1) { $('custResults').classList.remove('open'); return; }
        acTimer = setTimeout(() => searchCustomers(q), 250);
    });

    async function searchCustomers(q) {
        try {
            const r = await fetch(cfg.apiBase + '&action=search_customer&q=' + encodeURIComponent(q));
            const data = await r.json();
            const box = $('custResults');
            if (!data.items || data.items.length === 0) {
                box.innerHTML = '<div class="ac-item text-muted">Tidak ditemukan</div>';
            } else {
                box.innerHTML = data.items.map(c =>
                    `<div class="ac-item" data-id="${c.id}" data-name="${escapeHtml(c.name)}">
                        <strong>${escapeHtml(c.name)}</strong> <small>${escapeHtml(c.phone || '')} &middot; ${escapeHtml(c.code || '')}</small>
                    </div>`).join('');
            }
            box.classList.add('open');
        } catch (err) { console.error(err); }
    }

    $('custResults').addEventListener('click', (e) => {
        const item = e.target.closest('.ac-item[data-id]');
        if (!item) return;
        selectCustomer(parseInt(item.dataset.id), item.dataset.name);
    });

    async function selectCustomer(id, name) {
        customer = { id, name };
        $('custName').textContent = name;
        $('custChip').style.display = 'flex';
        $('custResults').classList.remove('open');
        $('custSearch').value = '';
        // load pets
        const sel = $('petSelect');
        sel.innerHTML = '<option value="">- tanpa hewan -</option>';
        try {
            const r = await fetch(cfg.apiBase + '&action=customer_pets&customer_id=' + id);
            const data = await r.json();
            (data.items || []).forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = p.name + (p.breed ? ' (' + p.breed + ')' : '');
                sel.appendChild(opt);
            });
        } catch (err) { console.error(err); }
    }

    $('clearCust').addEventListener('click', () => {
        customer = null;
        $('custChip').style.display = 'none';
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.pos-search')) $('custResults').classList.remove('open');
    });

    // ---------------- Payment shortcuts ----------------
    document.querySelectorAll('.quick-cash').forEach(b => {
        b.addEventListener('click', () => { $('paidInput').value = b.dataset.amt; recalc(); });
    });
    $('exactCash').addEventListener('click', () => {
        const t = recalc();
        $('paidInput').value = t.total;
        recalc();
    });

    // ---------------- Save sale ----------------
    async function saveSale(print) {
        const t = recalc();
        if (cart.length === 0) return;
        const btnP = $('saveSaleBtn'), btnO = $('saveOnlyBtn');
        btnP.disabled = btnO.disabled = true;
        const originalP = btnP.textContent;
        btnP.textContent = 'Menyimpan...';

        const payload = {
            customer_id: customer ? customer.id : null,
            pet_id: $('petSelect').value || null,
            items: cart.map(i => ({ service_id: i.service_id, qty: i.qty })),
            discount: parseInt($('discountInput').value) || 0,
            tax_rate: $('taxToggle').checked ? state.taxRate : 0,
            method: $('methodSelect').value,
            paid: t.paid,
        };

        try {
            const r = await fetch(cfg.apiBase + '&action=save_sale', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': cfg.csrf },
                body: JSON.stringify(payload),
            });
            const data = await r.json();
            if (!data.ok) throw new Error(data.error || 'Gagal menyimpan.');

            if (print) {
                // Send raw thermal print (server-side), then open the HTML receipt.
                fetch(cfg.apiBase + '&action=print_receipt&id=' + data.id)
                    .then(x => x.json())
                    .then(pr => { if (!pr.ok) alert('Tersimpan, tetapi cetak gagal: ' + pr.error); })
                    .catch(() => alert('Tersimpan, tetapi printer tidak merespons.'));
            }
            window.open(data.receipt_url, '_blank');
            alert('Transaksi ' + data.invoice_no + ' tersimpan!\nTotal: ' + fmt(data.total) + '\nKembalian: ' + fmt(data.change));
            resetSale();
        } catch (err) {
            alert('Error: ' + err.message);
        } finally {
            btnP.textContent = originalP;
            recalc();
        }
    }

    function resetSale() {
        cart = [];
        customer = null;
        $('custChip').style.display = 'none';
        $('discountInput').value = 0;
        $('paidInput').value = 0;
        $('methodSelect').value = 'cash';
        renderCart();
    }

    $('saveSaleBtn').addEventListener('click', () => saveSale(true));
    $('saveOnlyBtn').addEventListener('click', () => saveSale(false));

    function escapeHtml(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
            ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    renderCart();
})();
