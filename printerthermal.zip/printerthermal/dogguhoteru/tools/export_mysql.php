<?php

declare(strict_types=1);

/**
 * Export the current SQLite database to a MySQL-compatible .sql dump.
 *
 * Usage: php tools/export_mysql.php  > dogguhoteru.sql
 * (writes to stdout; the schema targets MySQL/MariaDB, utf8mb4)
 */

require __DIR__ . '/../config/config.php';
require __DIR__ . '/../app/Database.php';

$db = Database::conn();

// Explicit MySQL schema (mirrors the SQLite schema in install.php).
$schema = <<<'SQL'
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `logs`;
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `transaction_items`;
DROP TABLE IF EXISTS `transactions`;
DROP TABLE IF EXISTS `groomings`;
DROP TABLE IF EXISTS `boardings`;
DROP TABLE IF EXISTS `pets`;
DROP TABLE IF EXISTS `customers`;
DROP TABLE IF EXISTS `services`;
DROP TABLE IF EXISTS `rooms`;
DROP TABLE IF EXISTS `staff`;
DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `key`   VARCHAR(64) NOT NULL PRIMARY KEY,
  `value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `staff` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `username`      VARCHAR(64) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `name`          VARCHAR(128) NOT NULL,
  `role`          VARCHAR(32) NOT NULL DEFAULT 'cashier',
  `active`        TINYINT NOT NULL DEFAULT 1,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `customers` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `code`       VARCHAR(32) UNIQUE,
  `name`       VARCHAR(128) NOT NULL,
  `phone`      VARCHAR(32),
  `email`      VARCHAR(128),
  `address`    VARCHAR(255),
  `notes`      TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `pets` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `name`        VARCHAR(128) NOT NULL,
  `species`     VARCHAR(32) DEFAULT 'Dog',
  `breed`       VARCHAR(64),
  `gender`      VARCHAR(16),
  `weight`      DECIMAL(6,2),
  `birthday`    DATE,
  `temperament` VARCHAR(64),
  `vaccination` VARCHAR(128),
  `notes`       TEXT,
  `photo`       VARCHAR(255),
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_pets_customer` (`customer_id`),
  CONSTRAINT `fk_pets_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `services` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `code`        VARCHAR(32) UNIQUE,
  `name`        VARCHAR(128) NOT NULL,
  `category`    VARCHAR(32) NOT NULL DEFAULT 'Grooming',
  `price`       BIGINT NOT NULL DEFAULT 0,
  `unit`        VARCHAR(24) DEFAULT 'pcs',
  `description` TEXT,
  `active`      TINYINT NOT NULL DEFAULT 1,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `rooms` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `name`        VARCHAR(64) NOT NULL,
  `type`        VARCHAR(32) DEFAULT 'Standard',
  `daily_price` BIGINT NOT NULL DEFAULT 0,
  `status`      VARCHAR(24) NOT NULL DEFAULT 'available',
  `notes`       TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `transactions` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_no`     VARCHAR(32) NOT NULL UNIQUE,
  `customer_id`    INT,
  `pet_id`         INT,
  `staff_id`       INT,
  `subtotal`       BIGINT NOT NULL DEFAULT 0,
  `discount`       BIGINT NOT NULL DEFAULT 0,
  `tax`            BIGINT NOT NULL DEFAULT 0,
  `total`          BIGINT NOT NULL DEFAULT 0,
  `paid`           BIGINT NOT NULL DEFAULT 0,
  `change`         BIGINT NOT NULL DEFAULT 0,
  `payment_method` VARCHAR(24) DEFAULT 'cash',
  `status`         VARCHAR(24) NOT NULL DEFAULT 'paid',
  `notes`          TEXT,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_trx_created` (`created_at`),
  CONSTRAINT `fk_trx_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trx_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trx_staff` FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `transaction_items` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `transaction_id` INT NOT NULL,
  `service_id`     INT,
  `description`    VARCHAR(255) NOT NULL,
  `qty`            INT NOT NULL DEFAULT 1,
  `price`          BIGINT NOT NULL DEFAULT 0,
  `line_total`     BIGINT NOT NULL DEFAULT 0,
  KEY `idx_items_trx` (`transaction_id`),
  CONSTRAINT `fk_items_trx` FOREIGN KEY (`transaction_id`) REFERENCES `transactions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `payments` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `transaction_id` INT NOT NULL,
  `amount`         BIGINT NOT NULL DEFAULT 0,
  `method`         VARCHAR(24) DEFAULT 'cash',
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_pay_trx` FOREIGN KEY (`transaction_id`) REFERENCES `transactions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `boardings` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `pet_id`      INT NOT NULL,
  `room_id`     INT,
  `check_in`    DATETIME NOT NULL,
  `check_out`   DATETIME,
  `daily_price` BIGINT NOT NULL DEFAULT 0,
  `days`        INT NOT NULL DEFAULT 1,
  `total`       BIGINT NOT NULL DEFAULT 0,
  `status`      VARCHAR(24) NOT NULL DEFAULT 'checked_in',
  `notes`       TEXT,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_board_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_board_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_board_room` FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `groomings` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id`    INT NOT NULL,
  `pet_id`         INT NOT NULL,
  `groomer`        VARCHAR(128),
  `appointment_at` DATETIME NOT NULL,
  `service`        VARCHAR(128),
  `checklist`      TEXT,
  `status`         VARCHAR(24) NOT NULL DEFAULT 'scheduled',
  `notes`          TEXT,
  `before_photo`   VARCHAR(255),
  `after_photo`    VARCHAR(255),
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_groom_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_groom_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `logs` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `level`      VARCHAR(16) NOT NULL DEFAULT 'info',
  `message`    VARCHAR(255) NOT NULL,
  `context`    TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SQL;

// Tables in dependency order for inserts.
$tables = ['settings', 'staff', 'customers', 'pets', 'services', 'rooms',
           'transactions', 'transaction_items', 'payments', 'boardings', 'groomings', 'logs'];

$out = "-- Doggu Hoteru POS - MySQL dump generated from SQLite\n";
$out .= "-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
$out .= $schema . "\n";

foreach ($tables as $table) {
    $rows = $db->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
    if (!$rows) {
        continue;
    }
    $cols = array_keys($rows[0]);
    $colList = implode(', ', array_map(fn ($c) => "`$c`", $cols));
    $out .= "-- ---- $table (" . count($rows) . " rows) ----\n";
    $values = [];
    foreach ($rows as $row) {
        $vals = array_map(function ($v) use ($db) {
            if ($v === null) {
                return 'NULL';
            }
            if (is_int($v) || is_float($v)) {
                return (string) $v;
            }
            return $db->quote((string) $v);
        }, array_values($row));
        $values[] = '(' . implode(', ', $vals) . ')';
    }
    $out .= "INSERT INTO `$table` ($colList) VALUES\n" . implode(",\n", $values) . ";\n\n";
}

$out .= "SET FOREIGN_KEY_CHECKS = 1;\n";

fwrite(STDOUT, $out);
