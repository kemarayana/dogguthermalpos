<?php
/** Shared application shell. Expects $content and $pageTitle. */
$user = Auth::user();
$current = input('page', 'dashboard');

$nav = [
    ['dashboard',    'Dashboard',    'M3 12l9-9 9 9M5 10v10h14V10'],
    ['pos',          'Kasir (POS)',  'M3 3h18v4H3zM3 10h18v11H3z'],
    ['transactions', 'Transaksi',    'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2'],
    ['customers',    'Pelanggan',    'M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87'],
    ['pets',         'Hewan',        'M12 2a10 10 0 100 20 10 10 0 000-20z'],
    ['services',     'Layanan',      'M20 7L9 18l-5-5'],
    ['boarding',     'Penitipan',    'M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z'],
    ['rooms',        'Kandang',      'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z'],
    ['grooming',     'Grooming',     'M6 2v6a6 6 0 0012 0V2'],
    ['reports',      'Laporan',      'M3 3v18h18M9 17V9m4 8V5m4 12v-6'],
    ['settings',     'Pengaturan',   'M12 15a3 3 0 100-6 3 3 0 000 6z'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?> &middot; <?= e(setting('business_name', APP_NAME)) ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
<div class="app">
    <aside class="sidebar" id="sidebar">
        <div class="brand">
            <span class="brand-logo">🐾</span>
            <div>
                <strong><?= e(setting('business_name', APP_NAME)) ?></strong>
                <small><?= e(APP_TAGLINE) ?></small>
            </div>
        </div>
        <nav class="nav">
            <?php foreach ($nav as [$slug, $label, $icon]): ?>
                <a href="<?= url('page=' . $slug) ?>" class="nav-item <?= $current === $slug ? 'active' : '' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                         stroke-linecap="round" stroke-linejoin="round"><path d="<?= $icon ?>"/></svg>
                    <span><?= e($label) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        <div class="sidebar-foot">
            <small>v1.0 &middot; <?= e(CURRENCY) ?></small>
        </div>
    </aside>

    <div class="main">
        <header class="topbar">
            <button class="hamburger" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
            <h1><?= e($pageTitle) ?></h1>
            <div class="topbar-right">
                <span class="clock" id="clock"></span>
                <div class="user-chip">
                    <span class="avatar"><?= e(mb_substr($user['name'] ?? 'U', 0, 1)) ?></span>
                    <div>
                        <strong><?= e($user['name'] ?? '') ?></strong>
                        <small><?= e(ucfirst($user['role'] ?? '')) ?></small>
                    </div>
                </div>
                <a href="<?= url('page=logout') ?>" class="btn btn-ghost btn-sm">Keluar</a>
            </div>
        </header>

        <main class="content">
            <?php foreach (take_flashes() as $f): ?>
                <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
            <?php endforeach; ?>
            <?= $content ?>
        </main>
    </div>
</div>
<script src="<?= asset('js/app.js') ?>"></script>
</body>
</html>
