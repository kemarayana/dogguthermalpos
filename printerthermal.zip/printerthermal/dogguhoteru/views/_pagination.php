<?php
/** Reusable pagination partial. Expects $pg (from paginate()). */
if (!isset($pg) || $pg['pages'] <= 1) {
    return;
}
// Preserve current query string except the page number (p).
$qs = $_GET;
$build = function (int $p) use ($qs): string {
    $qs['p'] = $p;
    return BASE_URL . '/index.php?' . http_build_query($qs);
};
?>
<div class="pagination">
    <?php if ($pg['page'] > 1): ?>
        <a href="<?= e($build($pg['page'] - 1)) ?>">&laquo; Prev</a>
    <?php endif; ?>
    <?php for ($i = 1; $i <= $pg['pages']; $i++): ?>
        <?php if ($i === $pg['page']): ?>
            <span class="current"><?= $i ?></span>
        <?php else: ?>
            <a href="<?= e($build($i)) ?>"><?= $i ?></a>
        <?php endif; ?>
    <?php endfor; ?>
    <?php if ($pg['page'] < $pg['pages']): ?>
        <a href="<?= e($build($pg['page'] + 1)) ?>">Next &raquo;</a>
    <?php endif; ?>
</div>
