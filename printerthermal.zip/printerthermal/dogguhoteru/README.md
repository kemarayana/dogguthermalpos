# 🐾 Doggu Hoteru POS

A simple, self-contained Point-of-Sale system for a pet hotel & grooming business.
Built with **PHP 8 + SQLite + Vanilla JavaScript** — no frameworks, no Composer, no build step.

Currency: **IDR (Rupiah)**. Thermal printing reuses the working ESC/POS method from
`../test_print.php` (Mike42 escpos-php → `raw_print.ps1` → Windows spooler).

---

## Quick start

1. Copy the `dogguhoteru` folder into `C:\xampp\htdocs\printerthermal\`.
2. Start Apache from the XAMPP control panel.
3. Open <http://localhost/printerthermal/dogguhoteru/install.php>
   (or just open `index.php` — it auto-installs on first run).
4. Log in:

   | Role    | Username  | Password    |
   |---------|-----------|-------------|
   | Admin   | `admin`   | `admin123`  |
   | Kasir   | `kasir`   | `kasir123`  |
   | Groomer | `groomer` | `groomer123`|

To wipe and reseed the sample data: `install.php?fresh=1`.

---

## Modules

| Menu           | What it does                                                        |
|----------------|---------------------------------------------------------------------|
| **Dashboard**  | Today/month sales, 7-day trend, top services, recent transactions.  |
| **Kasir (POS)**| Customer/pet autocomplete, service tiles, cart, discount, tax, payment, save + print. |
| **Transaksi**  | Transaction history, date filter, receipt reprint, void (admin).    |
| **Pelanggan**  | Customer CRUD, search, pagination, spend statistics.                |
| **Hewan**      | Pet CRUD (breed, weight, birthday, vaccination…), visit history.    |
| **Layanan**    | Service catalog (Boarding, Grooming, Bath, Spa, Medicine, etc.).    |
| **Penitipan**  | Room occupancy board, check-in / check-out, day-based pricing.      |
| **Grooming**   | Appointments, groomer, checklist, status tracking.                  |
| **Laporan**    | Sales by category / method, top customers & pets, Excel export.     |
| **Pengaturan** | Business info, tax, printer, staff, backup / restore, test print.   |

---

## Printing

Printing is identical to the proven `test_print.php` setup:

- ESC/POS bytes are built in memory with `Mike42\Escpos` (library lives in the
  parent `printerthermal` folder — reused via a small autoloader).
- Bytes are streamed to the Windows print spooler with the **RAW** datatype using
  `raw_print.ps1` (winspool.drv `WritePrinter`), which is what the USB Xprinter
  XP-80 needs.

Set the Windows printer name and paper width (58 / 80 mm) in **Pengaturan**.
Use **Test Print** there to verify the connection.

---

## Project structure

```
dogguhoteru/
├── index.php            Front controller / router (?page=...)
├── install.php          Schema + IDR sample-data seeder
├── config/config.php    Paths, printer name, currency, tax
├── app/
│   ├── Database.php      PDO/SQLite abstraction
│   ├── Auth.php          Session auth against staff table
│   ├── PrinterService.php ESC/POS receipt builder + spooler send
│   └── helpers.php       e(), money(), csrf, flash, invoice no, ...
├── pages/               One file per screen (login, pos, api, receipt, ...)
├── views/               layout.php + shared partials
├── assets/css|js/       style.css, app.js, pos.js
└── data/                pos.sqlite (generated; web-access denied)
```

## Security notes

- All queries use **prepared statements** (PDO).
- Output is escaped with `e()`; forms are **CSRF-protected** (field + AJAX header).
- Server-side re-prices every cart line against the `services` table — client prices
  are never trusted.
- The `data/` folder is blocked from web access via `.htaccess`.
- For production: set `display_errors = 0` in `config/config.php` and change the
  default passwords in **Pengaturan → Staff**.
