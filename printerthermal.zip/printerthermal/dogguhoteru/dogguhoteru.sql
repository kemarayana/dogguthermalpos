-- Doggu Hoteru POS - MySQL dump generated from SQLite
-- Generated: 2026-07-09 19:57:02

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `logs`;
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `transaction_items`;
DROP TABLE IF EXISTS `transactions`;
DROP TABLE IF EXISTS `groomings`;
DROP TABLE IF EXISTS `boardings`;
DROP TABLE IF EXISTS `pets`;
DROP TABLE IF EXISTS `customers`;
DROP TABLE IF EXISTS `services`;
DROP TABLE IF EXISTS `rooms`;
DROP TABLE IF EXISTS `staff`;
DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `key`   VARCHAR(64) NOT NULL PRIMARY KEY,
  `value` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `staff` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `username`      VARCHAR(64) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `name`          VARCHAR(128) NOT NULL,
  `role`          VARCHAR(32) NOT NULL DEFAULT 'cashier',
  `active`        TINYINT NOT NULL DEFAULT 1,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `customers` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `code`       VARCHAR(32) UNIQUE,
  `name`       VARCHAR(128) NOT NULL,
  `phone`      VARCHAR(32),
  `email`      VARCHAR(128),
  `address`    VARCHAR(255),
  `notes`      TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `pets` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `name`        VARCHAR(128) NOT NULL,
  `species`     VARCHAR(32) DEFAULT 'Dog',
  `breed`       VARCHAR(64),
  `gender`      VARCHAR(16),
  `weight`      DECIMAL(6,2),
  `birthday`    DATE,
  `temperament` VARCHAR(64),
  `vaccination` VARCHAR(128),
  `notes`       TEXT,
  `photo`       VARCHAR(255),
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_pets_customer` (`customer_id`),
  CONSTRAINT `fk_pets_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `services` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `code`        VARCHAR(32) UNIQUE,
  `name`        VARCHAR(128) NOT NULL,
  `category`    VARCHAR(32) NOT NULL DEFAULT 'Grooming',
  `price`       BIGINT NOT NULL DEFAULT 0,
  `unit`        VARCHAR(24) DEFAULT 'pcs',
  `description` TEXT,
  `active`      TINYINT NOT NULL DEFAULT 1,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `rooms` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `name`        VARCHAR(64) NOT NULL,
  `type`        VARCHAR(32) DEFAULT 'Standard',
  `daily_price` BIGINT NOT NULL DEFAULT 0,
  `status`      VARCHAR(24) NOT NULL DEFAULT 'available',
  `notes`       TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `transactions` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_no`     VARCHAR(32) NOT NULL UNIQUE,
  `customer_id`    INT,
  `pet_id`         INT,
  `staff_id`       INT,
  `subtotal`       BIGINT NOT NULL DEFAULT 0,
  `discount`       BIGINT NOT NULL DEFAULT 0,
  `tax`            BIGINT NOT NULL DEFAULT 0,
  `total`          BIGINT NOT NULL DEFAULT 0,
  `paid`           BIGINT NOT NULL DEFAULT 0,
  `change`         BIGINT NOT NULL DEFAULT 0,
  `payment_method` VARCHAR(24) DEFAULT 'cash',
  `status`         VARCHAR(24) NOT NULL DEFAULT 'paid',
  `notes`          TEXT,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_trx_created` (`created_at`),
  CONSTRAINT `fk_trx_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trx_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_trx_staff` FOREIGN KEY (`staff_id`) REFERENCES `staff`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `transaction_items` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `transaction_id` INT NOT NULL,
  `service_id`     INT,
  `description`    VARCHAR(255) NOT NULL,
  `qty`            INT NOT NULL DEFAULT 1,
  `price`          BIGINT NOT NULL DEFAULT 0,
  `line_total`     BIGINT NOT NULL DEFAULT 0,
  KEY `idx_items_trx` (`transaction_id`),
  CONSTRAINT `fk_items_trx` FOREIGN KEY (`transaction_id`) REFERENCES `transactions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `payments` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `transaction_id` INT NOT NULL,
  `amount`         BIGINT NOT NULL DEFAULT 0,
  `method`         VARCHAR(24) DEFAULT 'cash',
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_pay_trx` FOREIGN KEY (`transaction_id`) REFERENCES `transactions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `boardings` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT NOT NULL,
  `pet_id`      INT NOT NULL,
  `room_id`     INT,
  `check_in`    DATETIME NOT NULL,
  `check_out`   DATETIME,
  `daily_price` BIGINT NOT NULL DEFAULT 0,
  `days`        INT NOT NULL DEFAULT 1,
  `total`       BIGINT NOT NULL DEFAULT 0,
  `status`      VARCHAR(24) NOT NULL DEFAULT 'checked_in',
  `notes`       TEXT,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_board_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_board_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_board_room` FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `groomings` (
  `id`             INT AUTO_INCREMENT PRIMARY KEY,
  `customer_id`    INT NOT NULL,
  `pet_id`         INT NOT NULL,
  `groomer`        VARCHAR(128),
  `appointment_at` DATETIME NOT NULL,
  `service`        VARCHAR(128),
  `checklist`      TEXT,
  `status`         VARCHAR(24) NOT NULL DEFAULT 'scheduled',
  `notes`          TEXT,
  `before_photo`   VARCHAR(255),
  `after_photo`    VARCHAR(255),
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_groom_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_groom_pet` FOREIGN KEY (`pet_id`) REFERENCES `pets`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `logs` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `level`      VARCHAR(16) NOT NULL DEFAULT 'info',
  `message`    VARCHAR(255) NOT NULL,
  `context`    TEXT,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- settings (11 rows) ----
INSERT INTO `settings` (`key`, `value`) VALUES
('business_name', 'Doggu Hoteru'),
('business_address', 'Jl. Sunset Road No. 88, Kuta, Bali'),
('business_phone', '0361-778899'),
('business_email', 'halo@dogguhoteru.id'),
('currency', 'IDR'),
('tax_rate', '11'),
('tax_enabled', '1'),
('printer_name', 'Xprinter XP-80'),
('printer_width', '80'),
('receipt_footer', 'Terima kasih! Sampai jumpa lagi ^_^'),
('timezone', 'Asia/Jakarta');

-- ---- staff (3 rows) ----
INSERT INTO `staff` (`id`, `username`, `password_hash`, `name`, `role`, `active`, `created_at`) VALUES
('1', 'admin', '$2y$10$FD9pVdxw7AmxCH0wcxfxsern5.IfdvzF/Ec/6fhyX6nydG9aTT7Au', 'Administrator', 'admin', '1', '2026-07-09 20:54:24'),
('2', 'kasir', '$2y$10$OuJXinwb7ZXaKwF56Sgy.ul7bymU61wiI0mNQFf0h19aAUk5eoExC', 'Putu Kasir', 'cashier', '1', '2026-07-09 20:54:24'),
('3', 'groomer', '$2y$10$kFayua0nL4oKFDM1AU10Q.MhOTX149oBkDWKwizZcMpkL23PKDZ4G', 'Kadek Groomer', 'groomer', '1', '2026-07-09 20:54:24');

-- ---- customers (5 rows) ----
INSERT INTO `customers` (`id`, `code`, `name`, `phone`, `email`, `address`, `notes`, `created_at`) VALUES
('1', 'CUST-0001', 'Wayan Sukarta', '081234567001', 'wayan@mail.com', 'Denpasar, Bali', NULL, '2026-07-09 20:54:24'),
('2', 'CUST-0002', 'Made Ayu', '081234567002', 'ayu@mail.com', 'Ubud, Gianyar', NULL, '2026-07-09 20:54:24'),
('3', 'CUST-0003', 'Ketut Wirawan', '081234567003', 'ketut@mail.com', 'Sanur, Denpasar', NULL, '2026-07-09 20:54:24'),
('4', 'CUST-0004', 'Nyoman Sari', '081234567004', 'sari@mail.com', 'Kuta, Badung', NULL, '2026-07-09 20:54:24'),
('5', 'CUST-0005', 'Gede Prana', '081234567005', 'gede@mail.com', 'Tabanan, Bali', NULL, '2026-07-09 20:54:24');

-- ---- pets (7 rows) ----
INSERT INTO `pets` (`id`, `customer_id`, `name`, `species`, `breed`, `gender`, `weight`, `birthday`, `temperament`, `vaccination`, `notes`, `photo`, `created_at`) VALUES
('1', '1', 'Bruno', 'Dog', 'Golden Retriever', 'Male', '28.5', NULL, 'Ramah', 'Rabies 2025', NULL, NULL, '2026-07-09 20:54:24'),
('2', '1', 'Coco', 'Dog', 'Pomeranian', 'Female', '3.2', NULL, 'Aktif', 'Rabies 2025', NULL, NULL, '2026-07-09 20:54:24'),
('3', '2', 'Milo', 'Cat', 'Persian', 'Male', '4.5', NULL, 'Pemalu', 'Rabies 2025', NULL, NULL, '2026-07-09 20:54:24'),
('4', '3', 'Rocky', 'Dog', 'Bulldog', 'Male', '22.0', NULL, 'Tenang', 'Rabies 2025', NULL, NULL, '2026-07-09 20:54:24'),
('5', '3', 'Luna', 'Dog', 'Beagle', 'Female', '11.0', NULL, 'Ramah', 'Rabies 2025', NULL, NULL, '2026-07-09 20:54:24'),
('6', '4', 'Snowy', 'Dog', 'Samoyed', 'Female', '20.0', NULL, 'Ceria', 'Rabies 2025', NULL, NULL, '2026-07-09 20:54:24'),
('7', '5', 'Max', 'Dog', 'German Shepherd', 'Male', '32.0', NULL, 'Waspada', 'Rabies 2025', NULL, NULL, '2026-07-09 20:54:24');

-- ---- services (14 rows) ----
INSERT INTO `services` (`id`, `code`, `name`, `category`, `price`, `unit`, `description`, `active`, `created_at`) VALUES
('1', 'BRD-STD', 'Penitipan Standard', 'Boarding', '120000', 'hari', NULL, '1', '2026-07-09 20:54:24'),
('2', 'BRD-DLX', 'Penitipan Deluxe', 'Boarding', '200000', 'hari', NULL, '1', '2026-07-09 20:54:24'),
('3', 'BRD-VIP', 'Penitipan VIP Suite', 'Boarding', '350000', 'hari', NULL, '1', '2026-07-09 20:54:24'),
('4', 'GRM-BSC', 'Grooming Basic', 'Grooming', '85000', 'ekor', NULL, '1', '2026-07-09 20:54:24'),
('5', 'GRM-FULL', 'Grooming Full Package', 'Grooming', '150000', 'ekor', NULL, '1', '2026-07-09 20:54:24'),
('6', 'BTH-STD', 'Mandi Standard', 'Bath', '60000', 'ekor', NULL, '1', '2026-07-09 20:54:24'),
('7', 'BTH-MED', 'Mandi Medicated', 'Bath', '95000', 'ekor', NULL, '1', '2026-07-09 20:54:24'),
('8', 'SPA-AROM', 'Spa Aromatherapy', 'Spa', '175000', 'ekor', NULL, '1', '2026-07-09 20:54:24'),
('9', 'MED-VAC', 'Vaksinasi', 'Medicine', '250000', 'dosis', NULL, '1', '2026-07-09 20:54:24'),
('10', 'MED-CHK', 'Pemeriksaan Dokter', 'Medicine', '100000', 'kali', NULL, '1', '2026-07-09 20:54:24'),
('11', 'TRP-ANT', 'Antar Jemput', 'Transport', '50000', 'trip', NULL, '1', '2026-07-09 20:54:24'),
('12', 'ACC-FOOD', 'Makanan Premium 1kg', 'Accessories', '85000', 'pcs', NULL, '1', '2026-07-09 20:54:24'),
('13', 'ACC-TOY', 'Mainan Anjing', 'Accessories', '45000', 'pcs', NULL, '1', '2026-07-09 20:54:24'),
('14', 'ACC-SHMP', 'Shampoo Anti Kutu', 'Accessories', '65000', 'botol', NULL, '1', '2026-07-09 20:54:24');

-- ---- rooms (6 rows) ----
INSERT INTO `rooms` (`id`, `name`, `type`, `daily_price`, `status`, `notes`) VALUES
('1', 'Kandang A1', 'Standard', '120000', 'occupied', NULL),
('2', 'Kandang A2', 'Standard', '120000', 'available', NULL),
('3', 'Kandang B1', 'Deluxe', '200000', 'available', NULL),
('4', 'Kandang B2', 'Deluxe', '200000', 'available', NULL),
('5', 'Suite VIP 1', 'VIP', '350000', 'available', NULL),
('6', 'Suite VIP 2', 'VIP', '350000', 'available', NULL);

-- ---- transactions (8 rows) ----
INSERT INTO `transactions` (`id`, `invoice_no`, `customer_id`, `pet_id`, `staff_id`, `subtotal`, `discount`, `tax`, `total`, `paid`, `change`, `payment_method`, `status`, `notes`, `created_at`) VALUES
('1', 'INV-20260625-0001', '1', '1', '2', '145000', '0', '15950', '160950', '170000', '9050', 'cash', 'paid', NULL, '2026-06-25 04:54:24'),
('2', 'INV-20260627-0002', '2', '3', '2', '175000', '17500', '17325', '174825', '180000', '5175', 'cash', 'paid', NULL, '2026-06-27 05:54:24'),
('3', 'INV-20260629-0003', '3', '4', '2', '300000', '0', '33000', '333000', '340000', '7000', 'qris', 'paid', NULL, '2026-06-29 06:54:24'),
('4', 'INV-20260701-0004', '4', '6', '2', '360000', '0', '39600', '399600', '400000', '400', 'debit', 'paid', NULL, '2026-07-01 07:54:24'),
('5', 'INV-20260703-0005', '5', '7', '2', '350000', '0', '38500', '388500', '390000', '1500', 'cash', 'paid', NULL, '2026-07-03 08:54:24'),
('6', 'INV-20260705-0006', '1', '1', '2', '215000', '10750', '22468', '226718', '230000', '3282', 'qris', 'paid', NULL, '2026-07-05 09:54:24'),
('7', 'INV-20260707-0007', '3', '4', '2', '160000', '0', '17600', '177600', '180000', '2400', 'cash', 'paid', NULL, '2026-07-07 10:54:24'),
('8', 'INV-20260709-0008', '2', '3', '2', '85000', '0', '9350', '94350', '100000', '5650', 'debit', 'paid', NULL, '2026-07-09 11:54:24');

-- ---- transaction_items (12 rows) ----
INSERT INTO `transaction_items` (`id`, `transaction_id`, `service_id`, `description`, `qty`, `price`, `line_total`) VALUES
('1', '1', '4', 'Grooming Basic', '1', '85000', '85000'),
('2', '1', '6', 'Mandi Standard', '1', '60000', '60000'),
('3', '2', '8', 'Spa Aromatherapy', '1', '175000', '175000'),
('4', '3', '5', 'Grooming Full Package', '2', '150000', '300000'),
('5', '4', '1', 'Penitipan Standard', '3', '120000', '360000'),
('6', '5', '9', 'Vaksinasi', '1', '250000', '250000'),
('7', '5', '10', 'Pemeriksaan Dokter', '1', '100000', '100000'),
('8', '6', '12', 'Makanan Premium 1kg', '2', '85000', '170000'),
('9', '6', '13', 'Mainan Anjing', '1', '45000', '45000'),
('10', '7', '7', 'Mandi Medicated', '1', '95000', '95000'),
('11', '7', '14', 'Shampoo Anti Kutu', '1', '65000', '65000'),
('12', '8', '4', 'Grooming Basic', '1', '85000', '85000');

-- ---- payments (8 rows) ----
INSERT INTO `payments` (`id`, `transaction_id`, `amount`, `method`, `created_at`) VALUES
('1', '1', '170000', 'cash', '2026-06-25 04:54:24'),
('2', '2', '180000', 'cash', '2026-06-27 05:54:24'),
('3', '3', '340000', 'qris', '2026-06-29 06:54:24'),
('4', '4', '400000', 'debit', '2026-07-01 07:54:24'),
('5', '5', '390000', 'cash', '2026-07-03 08:54:24'),
('6', '6', '230000', 'qris', '2026-07-05 09:54:24'),
('7', '7', '180000', 'cash', '2026-07-07 10:54:24'),
('8', '8', '100000', 'debit', '2026-07-09 11:54:24');

-- ---- boardings (2 rows) ----
INSERT INTO `boardings` (`id`, `customer_id`, `pet_id`, `room_id`, `check_in`, `check_out`, `daily_price`, `days`, `total`, `status`, `notes`, `created_at`) VALUES
('1', '4', '6', '1', '2026-07-08 05:54:24', NULL, '120000', '1', '0', 'checked_in', 'Alergi makanan ayam', '2026-07-09 20:54:24'),
('2', '1', '1', '3', '2026-06-29 19:54:25', '2026-07-02 19:54:25', '200000', '3', '600000', 'checked_out', NULL, '2026-07-09 20:54:25');

-- ---- groomings (2 rows) ----
INSERT INTO `groomings` (`id`, `customer_id`, `pet_id`, `groomer`, `appointment_at`, `service`, `checklist`, `status`, `notes`, `before_photo`, `after_photo`, `created_at`) VALUES
('1', '1', '2', 'Kadek Groomer', '2026-07-11 05:54:25', 'Grooming Full Package', '["Potong kuku","Bersih telinga","Potong bulu","Mandi"]', 'scheduled', NULL, NULL, NULL, '2026-07-09 20:54:25'),
('2', '3', '4', 'Kadek Groomer', '2026-07-09 09:54:25', 'Grooming Basic', '["Potong kuku","Mandi"]', 'completed', NULL, NULL, NULL, '2026-07-09 20:54:25');

SET FOREIGN_KEY_CHECKS = 1;
