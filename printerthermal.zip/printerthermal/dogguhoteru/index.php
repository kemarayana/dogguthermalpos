<?php

declare(strict_types=1);

/**
 * Front controller / router for Doggu Hoteru POS.
 *
 * Routing is query-string based: index.php?page=customers&action=edit&id=3
 * Each page lives in /pages/<page>.php and is included inside the shared layout
 * (except "login" and "api" which render standalone).
 */

session_start();

require __DIR__ . '/config/config.php';
require APP_PATH . '/Database.php';
require APP_PATH . '/helpers.php';
require APP_PATH . '/Auth.php';
require APP_PATH . '/PrinterService.php';

// Auto-install on first run if the database is missing.
if (!is_file(DB_FILE)) {
    require __DIR__ . '/install.php';
    exit;
}

$page = preg_replace('/[^a-z0-9_]/', '', (string) input('page', 'dashboard'));
if ($page === '') {
    $page = 'dashboard';
}

$pageFile = PAGE_PATH . '/' . $page . '.php';
if (!is_file($pageFile)) {
    http_response_code(404);
    $page = 'dashboard';
    $pageFile = PAGE_PATH . '/dashboard.php';
}

// Standalone pages (no chrome).
$standalone = ['login', 'logout', 'api', 'receipt'];

// Verify CSRF on every POST before running page logic.
csrf_check();

if (in_array($page, $standalone, true)) {
    if (!in_array($page, ['login', 'logout'], true)) {
        Auth::require();
    }
    require $pageFile;
    exit;
}

// Authenticated pages render inside the layout.
Auth::require();

// Page logic runs first (may set $pageTitle, may redirect), then buffered
// output is injected into the layout.
ob_start();
require $pageFile;
$content = ob_get_clean();

$pageTitle = $pageTitle ?? ucfirst($page);
require VIEW_PATH . '/layout.php';
