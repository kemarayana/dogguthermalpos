<?php
/** Log out and return to login. */
Auth::logout();
redirect('page=login');
