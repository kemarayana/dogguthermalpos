<?php
/** Grooming appointments with groomer, checklist and status. */
$pageTitle = 'Grooming';
$action = str_input('action', 'list');

$checklistItems = ['Potong kuku', 'Bersih telinga', 'Potong bulu', 'Mandi', 'Sikat gigi', 'Parfum', 'Anti kutu'];
$statuses = ['scheduled' => 'Terjadwal', 'in_progress' => 'Dikerjakan', 'completed' => 'Selesai', 'cancelled' => 'Batal'];

// ---- Save appointment ----
if (is_post() && $action === 'save') {
    $id = int_input('id');
    $petId = int_input('pet_id');
    if ($petId <= 0) { flash('Hewan wajib dipilih.', 'error'); redirect('page=grooming'); }
    $customerId = (int) Database::scalar('SELECT customer_id FROM pets WHERE id=?', [$petId]);
    $checklist = json_encode(array_values((array) input('checklist', [])));
    $data = [
        'customer_id'    => $customerId,
        'pet_id'         => $petId,
        'groomer'        => str_input('groomer'),
        'appointment_at' => str_input('appointment_at') ?: date('Y-m-d H:i:s'),
        'service'        => str_input('service'),
        'checklist'      => $checklist,
        'status'         => str_input('status', 'scheduled'),
        'notes'          => str_input('notes'),
    ];
    if ($id) {
        Database::update('groomings', $data, ['id' => $id]);
        flash('Appointment diperbarui.');
    } else {
        Database::insert('groomings', $data);
        flash('Appointment dibuat.');
    }
    redirect('page=grooming');
}

// ---- Quick status change ----
if (is_post() && $action === 'status') {
    Database::update('groomings', ['status' => str_input('status')], ['id' => int_input('id')]);
    flash('Status diperbarui.');
    redirect('page=grooming');
}

// ---- Delete ----
if (is_post() && $action === 'delete') {
    Database::delete('groomings', ['id' => int_input('id')]);
    flash('Appointment dihapus.');
    redirect('page=grooming');
}

// ---- Form ----
if ($action === 'create' || $action === 'edit') {
    $g = ['id' => 0, 'pet_id' => 0, 'groomer' => '', 'appointment_at' => date('Y-m-d H:i:s'),
          'service' => '', 'checklist' => '[]', 'status' => 'scheduled', 'notes' => ''];
    if ($action === 'edit') {
        $g = Database::one('SELECT * FROM groomings WHERE id=?', [int_input('id')]);
        if (!$g) { flash('Appointment tidak ditemukan.', 'error'); redirect('page=grooming'); }
    }
    $checked = json_decode($g['checklist'] ?: '[]', true) ?: [];
    $pets = Database::all('SELECT p.id, p.name, c.name AS owner FROM pets p JOIN customers c ON c.id=p.customer_id ORDER BY c.name, p.name');
    $groomers = Database::all("SELECT name FROM staff WHERE role IN ('groomer','admin') AND active=1");
    $svcs = Database::all("SELECT name FROM services WHERE category IN ('Grooming','Bath','Spa') AND active=1");
    ?>
    <div class="card" style="max-width:720px">
        <div class="card-head"><h2><?= $g['id'] ? 'Edit' : 'Buat' ?> Appointment Grooming</h2></div>
        <form method="post" action="<?= url('page=grooming&action=save') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $g['id'] ?>">
            <div class="card-body">
                <div class="form-grid">
                    <div class="form-row">
                        <label>Hewan <span class="req">*</span></label>
                        <select name="pet_id" required>
                            <option value="">- pilih hewan -</option>
                            <?php foreach ($pets as $p): ?>
                                <option value="<?= (int) $p['id'] ?>" <?= (int) $g['pet_id'] === (int) $p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?> — <?= e($p['owner']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Groomer</label>
                        <select name="groomer">
                            <option value="">- pilih -</option>
                            <?php foreach ($groomers as $gr): ?><option <?= $g['groomer'] === $gr['name'] ? 'selected' : '' ?>><?= e($gr['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Waktu</label>
                        <input type="datetime-local" name="appointment_at" value="<?= date('Y-m-d\TH:i', strtotime($g['appointment_at'])) ?>">
                    </div>
                    <div class="form-row">
                        <label>Layanan</label>
                        <select name="service">
                            <option value="">- pilih -</option>
                            <?php foreach ($svcs as $s): ?><option <?= $g['service'] === $s['name'] ? 'selected' : '' ?>><?= e($s['name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label>Checklist</label>
                    <div style="display:flex; flex-wrap:wrap; gap:12px">
                        <?php foreach ($checklistItems as $ci): ?>
                            <label style="display:flex; gap:6px; align-items:center; font-weight:400; margin:0">
                                <input type="checkbox" name="checklist[]" value="<?= e($ci) ?>" style="width:auto" <?= in_array($ci, $checked, true) ? 'checked' : '' ?>> <?= e($ci) ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-row">
                    <label>Status</label>
                    <select name="status">
                        <?php foreach ($statuses as $k => $v): ?><option value="<?= e($k) ?>" <?= $g['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <label>Catatan</label>
                    <textarea name="notes"><?= e($g['notes']) ?></textarea>
                </div>
            </div>
            <div class="modal-foot">
                <a href="<?= url('page=grooming') ?>" class="btn btn-ghost">Batal</a>
                <button class="btn" type="submit">Simpan</button>
            </div>
        </form>
    </div>
    <?php
    return;
}

// ---- List ----
$rows = Database::all(
    "SELECT g.*, p.name AS pet_name, c.name AS owner
     FROM groomings g JOIN pets p ON p.id=g.pet_id JOIN customers c ON c.id=g.customer_id
     ORDER BY g.appointment_at DESC LIMIT 100"
);
$badgeMap = ['scheduled' => 'badge-blue', 'in_progress' => 'badge-amber', 'completed' => 'badge-green', 'cancelled' => 'badge-red'];
?>
<div class="toolbar">
    <div class="spacer"></div>
    <a href="<?= url('page=grooming&action=create') ?>" class="btn">+ Buat Appointment</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Waktu</th><th>Hewan</th><th>Pemilik</th><th>Groomer</th><th>Layanan</th><th>Checklist</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="8" class="empty">Belum ada appointment.</td></tr><?php endif; ?>
            <?php foreach ($rows as $g):
                $cl = json_decode($g['checklist'] ?: '[]', true) ?: [];
            ?>
                <tr>
                    <td class="nowrap"><?= fdatetime($g['appointment_at']) ?></td>
                    <td class="fw-700">🐾 <?= e($g['pet_name']) ?></td>
                    <td><?= e($g['owner']) ?></td>
                    <td><?= e($g['groomer'] ?: '-') ?></td>
                    <td><?= e($g['service'] ?: '-') ?></td>
                    <td><span class="badge badge-gray"><?= count($cl) ?> item</span></td>
                    <td><span class="badge <?= $badgeMap[$g['status']] ?? 'badge-gray' ?>"><?= e($statuses[$g['status']] ?? $g['status']) ?></span></td>
                    <td>
                        <div class="actions">
                            <a class="icon-btn" href="<?= url('page=grooming&action=edit&id=' . $g['id']) ?>">✏️</a>
                            <form method="post" action="<?= url('page=grooming&action=delete') ?>" data-confirm="Hapus appointment?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $g['id'] ?>">
                                <button class="icon-btn del" type="submit">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
