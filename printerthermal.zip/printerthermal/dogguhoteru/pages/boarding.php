<?php
/** Boarding: room occupancy, check-in, check-out, history. */
$pageTitle = 'Penitipan';
$action = str_input('action', 'list');

// ---- Check-in ----
if (is_post() && $action === 'checkin') {
    $petId = int_input('pet_id');
    $roomId = int_input('room_id');
    $checkIn = str_input('check_in') ?: date('Y-m-d H:i:s');
    if ($petId <= 0 || $roomId <= 0) {
        flash('Hewan dan kamar wajib dipilih.', 'error');
        redirect('page=boarding');
    }
    $customerId = (int) Database::scalar('SELECT customer_id FROM pets WHERE id=?', [$petId]);
    $price = (int) Database::scalar('SELECT daily_price FROM rooms WHERE id=?', [$roomId]);
    Database::insert('boardings', [
        'customer_id' => $customerId, 'pet_id' => $petId, 'room_id' => $roomId,
        'check_in' => $checkIn, 'daily_price' => $price, 'days' => 1, 'total' => 0,
        'status' => 'checked_in', 'notes' => str_input('notes'),
    ]);
    Database::update('rooms', ['status' => 'occupied'], ['id' => $roomId]);
    flash('Check-in berhasil.');
    redirect('page=boarding');
}

// ---- Check-out ----
if (is_post() && $action === 'checkout') {
    $id = int_input('id');
    $b = Database::one('SELECT * FROM boardings WHERE id=?', [$id]);
    if ($b) {
        $checkOut = date('Y-m-d H:i:s');
        $days = max(1, (int) ceil((strtotime($checkOut) - strtotime($b['check_in'])) / 86400));
        $total = $days * (int) $b['daily_price'];
        Database::update('boardings', [
            'check_out' => $checkOut, 'days' => $days, 'total' => $total, 'status' => 'checked_out',
        ], ['id' => $id]);
        if ($b['room_id']) {
            Database::update('rooms', ['status' => 'available'], ['id' => $b['room_id']]);
        }
        flash("Check-out berhasil. $days hari = " . money($total) . '. Buat transaksi di Kasir untuk penagihan.');
    }
    redirect('page=boarding');
}

$rooms = Database::all('SELECT * FROM rooms ORDER BY name');
$active = Database::all(
    "SELECT b.*, p.name AS pet_name, c.name AS owner, r.name AS room_name
     FROM boardings b
     JOIN pets p ON p.id=b.pet_id
     JOIN customers c ON c.id=b.customer_id
     LEFT JOIN rooms r ON r.id=b.room_id
     WHERE b.status='checked_in' ORDER BY b.check_in"
);
$history = Database::all(
    "SELECT b.*, p.name AS pet_name, c.name AS owner, r.name AS room_name
     FROM boardings b
     JOIN pets p ON p.id=b.pet_id
     JOIN customers c ON c.id=b.customer_id
     LEFT JOIN rooms r ON r.id=b.room_id
     WHERE b.status='checked_out' ORDER BY b.id DESC LIMIT 15"
);
$pets = Database::all('SELECT p.id, p.name, c.name AS owner FROM pets p JOIN customers c ON c.id=p.customer_id ORDER BY c.name, p.name');
$freeRooms = array_filter($rooms, fn ($r) => $r['status'] === 'available');
$occupied = count($rooms) - count($freeRooms);
?>
<div class="grid grid-4 mb-2">
    <div class="stat"><div class="stat-icon i-cyan">🏠</div><div><div class="stat-label">Total Kamar</div><div class="stat-value"><?= count($rooms) ?></div></div></div>
    <div class="stat"><div class="stat-icon i-amber">🐕</div><div><div class="stat-label">Terisi</div><div class="stat-value"><?= $occupied ?></div></div></div>
    <div class="stat"><div class="stat-icon i-green">✅</div><div><div class="stat-label">Kosong</div><div class="stat-value"><?= count($freeRooms) ?></div></div></div>
    <div class="stat"><div class="stat-icon i-blue">📋</div><div><div class="stat-label">Tamu Aktif</div><div class="stat-value"><?= count($active) ?></div></div></div>
</div>

<div class="toolbar">
    <div class="spacer"></div>
    <button class="btn" data-modal-open="checkinModal" <?= $freeRooms ? '' : 'disabled' ?>>+ Check-in Baru</button>
</div>

<!-- Room status board -->
<div class="card mb-2">
    <div class="card-head"><h2>Status Kamar</h2><a class="btn btn-sm btn-ghost" href="<?= url('page=rooms') ?>">⚙️ Kelola Kandang</a></div>
    <div class="card-body">
        <div class="service-grid">
            <?php foreach ($rooms as $r): ?>
                <div class="service-tile" style="cursor:default; border-color:<?= $r['status'] === 'occupied' ? 'var(--warning)' : 'var(--success)' ?>">
                    <div class="cat"><?= e($r['type']) ?></div>
                    <div class="nm"><?= e($r['name']) ?></div>
                    <div class="pr"><?= money($r['daily_price']) ?>/hari</div>
                    <span class="badge <?= $r['status'] === 'occupied' ? 'badge-amber' : 'badge-green' ?> mt-1"><?= $r['status'] === 'occupied' ? 'Terisi' : 'Kosong' ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Active guests -->
<div class="card mb-2">
    <div class="card-head"><h2>Tamu Menginap</h2></div>
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Hewan</th><th>Pemilik</th><th>Kamar</th><th>Check-in</th><th class="num">Hari</th><th class="num">Estimasi</th><th></th></tr></thead>
            <tbody>
            <?php if (!$active): ?><tr><td colspan="7" class="empty">Tidak ada tamu menginap.</td></tr><?php endif; ?>
            <?php foreach ($active as $b):
                $days = max(1, (int) ceil((time() - strtotime($b['check_in'])) / 86400));
                $est = $days * (int) $b['daily_price'];
            ?>
                <tr>
                    <td class="fw-700">🐾 <?= e($b['pet_name']) ?></td>
                    <td><?= e($b['owner']) ?></td>
                    <td><?= e($b['room_name'] ?? '-') ?></td>
                    <td class="nowrap"><?= fdatetime($b['check_in']) ?></td>
                    <td class="num"><?= $days ?></td>
                    <td class="num fw-700"><?= money($est) ?></td>
                    <td>
                        <form method="post" action="<?= url('page=boarding&action=checkout') ?>" data-confirm="Check-out sekarang? Estimasi <?= money($est) ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
                            <button class="btn btn-warning btn-sm" type="submit">Check-out</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- History -->
<div class="card">
    <div class="card-head"><h2>Riwayat Penitipan</h2></div>
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Hewan</th><th>Pemilik</th><th>Kamar</th><th>Check-in</th><th>Check-out</th><th class="num">Hari</th><th class="num">Total</th></tr></thead>
            <tbody>
            <?php if (!$history): ?><tr><td colspan="7" class="empty">Belum ada riwayat.</td></tr><?php endif; ?>
            <?php foreach ($history as $b): ?>
                <tr>
                    <td class="fw-700"><?= e($b['pet_name']) ?></td>
                    <td><?= e($b['owner']) ?></td>
                    <td><?= e($b['room_name'] ?? '-') ?></td>
                    <td class="nowrap"><?= fdate($b['check_in']) ?></td>
                    <td class="nowrap"><?= fdate($b['check_out']) ?></td>
                    <td class="num"><?= (int) $b['days'] ?></td>
                    <td class="num fw-700"><?= money($b['total']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Check-in modal -->
<div class="modal-overlay" id="checkinModal">
    <div class="modal">
        <div class="modal-head"><h3>Check-in Baru</h3><button class="modal-close" data-modal-close>&times;</button></div>
        <form method="post" action="<?= url('page=boarding&action=checkin') ?>">
            <?= csrf_field() ?>
            <div class="modal-body">
                <div class="form-row">
                    <label>Hewan <span class="req">*</span></label>
                    <select name="pet_id" required>
                        <option value="">- pilih hewan -</option>
                        <?php foreach ($pets as $p): ?>
                            <option value="<?= (int) $p['id'] ?>"><?= e($p['name']) ?> — <?= e($p['owner']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <label>Kamar <span class="req">*</span></label>
                    <select name="room_id" required>
                        <option value="">- pilih kamar kosong -</option>
                        <?php foreach ($freeRooms as $r): ?>
                            <option value="<?= (int) $r['id'] ?>"><?= e($r['name']) ?> (<?= e($r['type']) ?>) — <?= money($r['daily_price']) ?>/hari</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row">
                    <label>Waktu Check-in</label>
                    <input type="datetime-local" name="check_in" value="<?= date('Y-m-d\TH:i') ?>">
                </div>
                <div class="form-row">
                    <label>Catatan</label>
                    <textarea name="notes" placeholder="Alergi, kebiasaan makan, obat..."></textarea>
                </div>
            </div>
            <div class="modal-foot">
                <button type="button" class="btn btn-ghost" data-modal-close>Batal</button>
                <button class="btn btn-success" type="submit">Check-in</button>
            </div>
        </form>
    </div>
</div>
