<?php
/** Pet CRUD - multiple pets per customer, with visit history. */
$pageTitle = 'Hewan';
$action = str_input('action', 'list');

$speciesOpts = ['Dog', 'Cat', 'Rabbit', 'Bird', 'Other'];
$genderOpts  = ['Male', 'Female'];
$tempOpts    = ['Ramah', 'Aktif', 'Tenang', 'Pemalu', 'Waspada', 'Agresif'];

// ---- Save ----
if (is_post() && $action === 'save') {
    $id = int_input('id');
    $customerId = int_input('customer_id');
    $name = str_input('name');
    if ($customerId <= 0 || $name === '') {
        flash('Pemilik dan nama hewan wajib diisi.', 'error');
        redirect('page=pets');
    }
    $data = [
        'customer_id' => $customerId,
        'name'        => $name,
        'species'     => str_input('species', 'Dog'),
        'breed'       => str_input('breed'),
        'gender'      => str_input('gender'),
        'weight'      => (float) str_input('weight', '0') ?: null,
        'birthday'    => str_input('birthday') ?: null,
        'temperament' => str_input('temperament'),
        'vaccination' => str_input('vaccination'),
        'notes'       => str_input('notes'),
    ];
    if ($id) {
        Database::update('pets', $data, ['id' => $id]);
        flash('Data hewan diperbarui.');
    } else {
        Database::insert('pets', $data);
        flash('Hewan ditambahkan.');
    }
    redirect('page=pets' . ($customerId ? '&customer_id=' . $customerId : ''));
}

// ---- Delete ----
if (is_post() && $action === 'delete') {
    $cid = (int) Database::scalar('SELECT customer_id FROM pets WHERE id=?', [int_input('id')]);
    Database::delete('pets', ['id' => int_input('id')]);
    flash('Hewan dihapus.');
    redirect('page=pets' . ($cid ? '&customer_id=' . $cid : ''));
}

// ---- Detail (visit history) ----
if ($action === 'view') {
    $pet = Database::one('SELECT p.*, c.name AS owner, c.phone FROM pets p JOIN customers c ON c.id=p.customer_id WHERE p.id=?', [int_input('id')]);
    if (!$pet) { flash('Hewan tidak ditemukan.', 'error'); redirect('page=pets'); }
    $visits = Database::all(
        "SELECT t.invoice_no, t.created_at, t.total, ti.description
         FROM transactions t JOIN transaction_items ti ON ti.transaction_id=t.id
         WHERE t.pet_id=? ORDER BY t.id DESC LIMIT 30", [$pet['id']]
    );
    $grooms = Database::all("SELECT * FROM groomings WHERE pet_id=? ORDER BY appointment_at DESC", [$pet['id']]);
    ?>
    <a href="<?= url('page=pets') ?>" class="btn btn-ghost btn-sm mb-2">&laquo; Kembali</a>
    <div class="grid grid-2">
        <div class="card">
            <div class="card-head"><h2>🐾 <?= e($pet['name']) ?></h2><a class="btn btn-sm" href="<?= url('page=pets&action=edit&id=' . $pet['id']) ?>">Edit</a></div>
            <div class="card-body">
                <table class="tbl">
                    <tr><th>Pemilik</th><td><?= e($pet['owner']) ?> (<?= e($pet['phone']) ?>)</td></tr>
                    <tr><th>Jenis</th><td><?= e($pet['species']) ?> &middot; <?= e($pet['breed'] ?: '-') ?></td></tr>
                    <tr><th>Kelamin</th><td><?= e($pet['gender'] ?: '-') ?></td></tr>
                    <tr><th>Berat</th><td><?= $pet['weight'] ? e($pet['weight']) . ' kg' : '-' ?></td></tr>
                    <tr><th>Ulang Tahun</th><td><?= fdate($pet['birthday']) ?></td></tr>
                    <tr><th>Temperamen</th><td><?= e($pet['temperament'] ?: '-') ?></td></tr>
                    <tr><th>Vaksinasi</th><td><?= e($pet['vaccination'] ?: '-') ?></td></tr>
                    <tr><th>Catatan</th><td><?= e($pet['notes'] ?: '-') ?></td></tr>
                </table>
            </div>
        </div>
        <div class="card">
            <div class="card-head"><h2>Riwayat Kunjungan</h2></div>
            <div class="table-wrap">
                <table class="tbl">
                    <thead><tr><th>Tanggal</th><th>Layanan</th><th>Invoice</th></tr></thead>
                    <tbody>
                    <?php if (!$visits): ?><tr><td colspan="3" class="empty">Belum ada kunjungan.</td></tr><?php endif; ?>
                    <?php foreach ($visits as $v): ?>
                        <tr><td class="nowrap"><?= fdate($v['created_at']) ?></td><td><?= e($v['description']) ?></td><td class="text-muted"><?= e($v['invoice_no']) ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
    return;
}

// ---- Create / Edit ----
if ($action === 'create' || $action === 'edit') {
    $pet = ['id' => 0, 'customer_id' => int_input('customer_id'), 'name' => '', 'species' => 'Dog',
            'breed' => '', 'gender' => '', 'weight' => '', 'birthday' => '', 'temperament' => '',
            'vaccination' => '', 'notes' => ''];
    if ($action === 'edit') {
        $pet = Database::one('SELECT * FROM pets WHERE id=?', [int_input('id')]);
        if (!$pet) { flash('Hewan tidak ditemukan.', 'error'); redirect('page=pets'); }
    }
    $customers = Database::all('SELECT id, name FROM customers ORDER BY name');
    ?>
    <div class="card" style="max-width:720px">
        <div class="card-head"><h2><?= $pet['id'] ? 'Edit' : 'Tambah' ?> Hewan</h2></div>
        <form method="post" action="<?= url('page=pets&action=save') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $pet['id'] ?>">
            <div class="card-body">
                <div class="form-grid">
                    <div class="form-row">
                        <label>Pemilik <span class="req">*</span></label>
                        <select name="customer_id" required>
                            <option value="">- pilih pemilik -</option>
                            <?php foreach ($customers as $c): ?>
                                <option value="<?= (int) $c['id'] ?>" <?= (int) $pet['customer_id'] === (int) $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Nama Hewan <span class="req">*</span></label>
                        <input type="text" name="name" required value="<?= e($pet['name']) ?>">
                    </div>
                    <div class="form-row">
                        <label>Jenis</label>
                        <select name="species">
                            <?php foreach ($speciesOpts as $o): ?><option <?= $pet['species'] === $o ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Ras / Breed</label>
                        <input type="text" name="breed" value="<?= e($pet['breed']) ?>">
                    </div>
                    <div class="form-row">
                        <label>Kelamin</label>
                        <select name="gender">
                            <option value="">-</option>
                            <?php foreach ($genderOpts as $o): ?><option <?= $pet['gender'] === $o ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Berat (kg)</label>
                        <input type="number" step="0.1" name="weight" value="<?= e($pet['weight']) ?>">
                    </div>
                    <div class="form-row">
                        <label>Ulang Tahun</label>
                        <input type="date" name="birthday" value="<?= e($pet['birthday']) ?>">
                    </div>
                    <div class="form-row">
                        <label>Temperamen</label>
                        <select name="temperament">
                            <option value="">-</option>
                            <?php foreach ($tempOpts as $o): ?><option <?= $pet['temperament'] === $o ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label>Vaksinasi</label>
                    <input type="text" name="vaccination" value="<?= e($pet['vaccination']) ?>" placeholder="mis. Rabies 2025, Distemper">
                </div>
                <div class="form-row">
                    <label>Catatan</label>
                    <textarea name="notes"><?= e($pet['notes']) ?></textarea>
                </div>
            </div>
            <div class="modal-foot">
                <a href="<?= url('page=pets') ?>" class="btn btn-ghost">Batal</a>
                <button class="btn" type="submit">Simpan</button>
            </div>
        </form>
    </div>
    <?php
    return;
}

// ---- List ----
$q = str_input('q');
$filterCust = int_input('customer_id');
$conds = [];
$params = [];
if ($q !== '') { $conds[] = '(p.name LIKE ? OR p.breed LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($filterCust) { $conds[] = 'p.customer_id = ?'; $params[] = $filterCust; }
$where = $conds ? 'WHERE ' . implode(' AND ', $conds) : '';

$rows = Database::all(
    "SELECT p.*, c.name AS owner FROM pets p JOIN customers c ON c.id=p.customer_id
     $where ORDER BY p.name", $params
);
$custName = $filterCust ? Database::scalar('SELECT name FROM customers WHERE id=?', [$filterCust]) : null;
?>
<div class="toolbar">
    <form class="search-box" method="get">
        <input type="hidden" name="page" value="pets">
        <?php if ($filterCust): ?><input type="hidden" name="customer_id" value="<?= $filterCust ?>"><?php endif; ?>
        <input type="text" name="q" placeholder="Cari hewan / ras..." value="<?= e($q) ?>">
    </form>
    <?php if ($custName): ?><span class="badge badge-blue">Pemilik: <?= e($custName) ?></span> <a href="<?= url('page=pets') ?>" class="text-muted">&times; reset</a><?php endif; ?>
    <div class="spacer"></div>
    <a href="<?= url('page=pets&action=create' . ($filterCust ? '&customer_id=' . $filterCust : '')) ?>" class="btn">+ Tambah Hewan</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Nama</th><th>Pemilik</th><th>Jenis / Ras</th><th>Kelamin</th><th>Berat</th><th>Temperamen</th><th></th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="7" class="empty">Tidak ada hewan.</td></tr><?php endif; ?>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="fw-700"><?= e($r['name']) ?></td>
                    <td><?= e($r['owner']) ?></td>
                    <td><?= e($r['species']) ?> <small class="text-muted"><?= e($r['breed']) ?></small></td>
                    <td><?= e($r['gender'] ?: '-') ?></td>
                    <td><?= $r['weight'] ? e($r['weight']) . ' kg' : '-' ?></td>
                    <td><?= $r['temperament'] ? '<span class="badge badge-gray">' . e($r['temperament']) . '</span>' : '-' ?></td>
                    <td>
                        <div class="actions">
                            <a class="icon-btn" href="<?= url('page=pets&action=view&id=' . $r['id']) ?>">👁️</a>
                            <a class="icon-btn" href="<?= url('page=pets&action=edit&id=' . $r['id']) ?>">✏️</a>
                            <form method="post" action="<?= url('page=pets&action=delete') ?>" data-confirm="Hapus hewan ini?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button class="icon-btn del" type="submit">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
