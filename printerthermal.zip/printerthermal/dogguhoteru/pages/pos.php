<?php
/** POS / Kasir screen. */
$pageTitle = 'Kasir (POS)';
$services = Database::all("SELECT id, name, category, price, unit FROM services WHERE active=1 ORDER BY category, name");
$categories = array_values(array_unique(array_column($services, 'category')));
$taxEnabled = (int) setting('tax_enabled', 1) === 1;
$taxRate = (float) setting('tax_rate', DEFAULT_TAX_RATE);
?>
<div class="pos">
    <!-- Left: catalog -->
    <div>
        <div class="card mb-2">
            <div class="card-body">
                <label>Pelanggan</label>
                <div class="pos-search">
                    <input type="text" id="custSearch" placeholder="Cari nama / telepon pelanggan... (opsional)" autocomplete="off">
                    <div class="autocomplete" id="custResults"></div>
                </div>
                <div id="custChip" style="display:none" class="chip-customer mt-1">
                    <div>
                        <strong id="custName"></strong>
                        <div><select id="petSelect" style="margin-top:6px; max-width:220px"><option value="">- tanpa hewan -</option></select></div>
                    </div>
                    <button class="btn btn-ghost btn-sm" type="button" id="clearCust">&times;</button>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-head">
                <h2>Layanan</h2>
                <div class="search-box" style="min-width:220px">
                    <input type="text" id="svcSearch" placeholder="Cari layanan...">
                </div>
            </div>
            <div class="card-body">
                <div style="margin-bottom:14px; display:flex; gap:8px; flex-wrap:wrap">
                    <button class="btn btn-ghost btn-sm cat-filter active" data-cat="">Semua</button>
                    <?php foreach ($categories as $c): ?>
                        <button class="btn btn-ghost btn-sm cat-filter" data-cat="<?= e($c) ?>"><?= e($c) ?></button>
                    <?php endforeach; ?>
                </div>
                <div class="service-grid" id="serviceGrid">
                    <?php foreach ($services as $s): ?>
                        <button type="button" class="service-tile" data-cat="<?= e($s['category']) ?>"
                                data-id="<?= (int) $s['id'] ?>" data-name="<?= e($s['name']) ?>" data-price="<?= (int) $s['price'] ?>">
                            <div class="cat"><?= e($s['category']) ?></div>
                            <div class="nm"><?= e($s['name']) ?></div>
                            <div class="pr"><?= money($s['price']) ?><small class="text-muted">/<?= e($s['unit']) ?></small></div>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Right: cart -->
    <div class="pos-cart">
        <div class="card">
            <div class="card-head"><h2>🧾 Keranjang</h2><button class="btn btn-ghost btn-sm" type="button" id="clearCart">Kosongkan</button></div>
            <div class="card-body">
                <div class="cart-items" id="cartItems">
                    <div class="pos-empty" id="cartEmpty">Belum ada item. Pilih layanan di sebelah kiri.</div>
                </div>

                <div class="mt-2">
                    <div class="totals-row"><span>Subtotal</span><strong id="subtotalTxt">Rp 0</strong></div>
                    <div class="totals-row">
                        <span>Diskon (Rp)</span>
                        <input type="number" id="discountInput" min="0" value="0" style="width:120px; text-align:right; padding:5px 8px">
                    </div>
                    <div class="totals-row">
                        <label style="display:flex; gap:6px; align-items:center; margin:0; font-weight:400">
                            <input type="checkbox" id="taxToggle" style="width:auto" <?= $taxEnabled ? 'checked' : '' ?>>
                            Pajak (<?= rtrim(rtrim((string) $taxRate, '0'), '.') ?>%)
                        </label>
                        <strong id="taxTxt">Rp 0</strong>
                    </div>
                    <div class="totals-row grand"><span>TOTAL</span><span id="totalTxt">Rp 0</span></div>
                </div>

                <hr style="border:none; border-top:1px solid var(--border); margin:16px 0">

                <div class="form-grid" style="gap:12px">
                    <div class="form-row" style="margin:0">
                        <label>Metode Bayar</label>
                        <select id="methodSelect">
                            <option value="cash">Tunai</option>
                            <option value="qris">QRIS</option>
                            <option value="debit">Debit</option>
                            <option value="credit">Kartu Kredit</option>
                            <option value="transfer">Transfer</option>
                        </select>
                    </div>
                    <div class="form-row" style="margin:0">
                        <label>Uang Dibayar</label>
                        <input type="number" id="paidInput" min="0" value="0" style="text-align:right">
                    </div>
                </div>
                <div class="totals-row mt-2"><span>Kembalian</span><strong id="changeTxt">Rp 0</strong></div>
                <div class="flex mt-1" style="flex-wrap:wrap; gap:6px">
                    <?php foreach ([50000, 100000, 150000, 200000] as $qk): ?>
                        <button type="button" class="btn btn-ghost btn-sm quick-cash" data-amt="<?= $qk ?>"><?= number_format($qk, 0, ',', '.') ?></button>
                    <?php endforeach; ?>
                    <button type="button" class="btn btn-ghost btn-sm" id="exactCash">Uang Pas</button>
                </div>

                <button class="btn btn-success btn-lg btn-block mt-3" id="saveSaleBtn" disabled>💾 Simpan &amp; Cetak Struk</button>
                <button class="btn btn-ghost btn-block mt-1" id="saveOnlyBtn" disabled>Simpan Tanpa Cetak</button>
            </div>
        </div>
    </div>
</div>

<script>
window.POS_CONFIG = {
    apiBase: <?= json_encode(url('page=api')) ?>,
    taxRate: <?= json_encode($taxRate) ?>,
    csrf: <?= json_encode(csrf_token()) ?>
};
</script>
<script src="<?= asset('js/pos.js') ?>"></script>
