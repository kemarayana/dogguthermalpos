<?php
/** Login screen (standalone, no layout). */
if (Auth::check()) {
    redirect('page=dashboard');
}

$error = null;
if (is_post()) {
    $username = str_input('username');
    $password = (string) input('password', '');
    if (Auth::attempt($username, $password)) {
        redirect('page=dashboard');
    }
    $error = 'Username atau password salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk &middot; <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
</head>
<body>
<div class="login-wrap">
    <form class="login-card" method="post" action="<?= url('page=login') ?>">
        <?= csrf_field() ?>
        <div class="logo">🐾</div>
        <h1><?= e(APP_NAME) ?></h1>
        <p class="sub"><?= e(APP_TAGLINE) ?></p>

        <?php if ($error): ?>
            <div class="flash flash-error"><?= e($error) ?></div>
        <?php endif; ?>

        <div class="form-row">
            <label>Username</label>
            <input type="text" name="username" autofocus required value="<?= e(input('username', '')) ?>">
        </div>
        <div class="form-row">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <button class="btn btn-lg btn-block" type="submit">Masuk</button>

        <div class="creds">
            Demo: <strong>admin / admin123</strong> &middot; <strong>kasir / kasir123</strong>
        </div>
    </form>
</div>
</body>
</html>
