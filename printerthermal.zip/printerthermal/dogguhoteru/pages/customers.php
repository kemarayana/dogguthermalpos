<?php
/** Customer CRUD with search + pagination. */
$pageTitle = 'Pelanggan';
$action = str_input('action', 'list');

// ---- Save (create / update) ----
if (is_post() && $action === 'save') {
    $id = int_input('id');
    $name = str_input('name');
    if ($name === '') {
        flash('Nama pelanggan wajib diisi.', 'error');
        redirect('page=customers&action=' . ($id ? "edit&id=$id" : 'create'));
    }
    $data = [
        'name'    => $name,
        'phone'   => str_input('phone'),
        'email'   => str_input('email'),
        'address' => str_input('address'),
        'notes'   => str_input('notes'),
    ];
    if ($id) {
        Database::update('customers', $data, ['id' => $id]);
        flash('Pelanggan diperbarui.');
    } else {
        $data['code'] = 'CUST-' . str_pad((string) (((int) Database::scalar('SELECT COALESCE(MAX(id),0) FROM customers')) + 1), 4, '0', STR_PAD_LEFT);
        Database::insert('customers', $data);
        flash('Pelanggan ditambahkan.');
    }
    redirect('page=customers');
}

// ---- Delete ----
if (is_post() && $action === 'delete') {
    $id = int_input('id');
    Database::delete('customers', ['id' => $id]);
    flash('Pelanggan dihapus.');
    redirect('page=customers');
}

// ---- Create / Edit form ----
if ($action === 'create' || $action === 'edit') {
    $cust = ['id' => 0, 'name' => '', 'phone' => '', 'email' => '', 'address' => '', 'notes' => ''];
    if ($action === 'edit') {
        $cust = Database::one('SELECT * FROM customers WHERE id=?', [int_input('id')]);
        if (!$cust) { flash('Pelanggan tidak ditemukan.', 'error'); redirect('page=customers'); }
    }
    ?>
    <div class="card" style="max-width:680px">
        <div class="card-head"><h2><?= $cust['id'] ? 'Edit' : 'Tambah' ?> Pelanggan</h2></div>
        <form method="post" action="<?= url('page=customers&action=save') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $cust['id'] ?>">
            <div class="card-body">
                <div class="form-grid">
                    <div class="form-row">
                        <label>Nama <span class="req">*</span></label>
                        <input type="text" name="name" required value="<?= e($cust['name']) ?>">
                    </div>
                    <div class="form-row">
                        <label>Telepon</label>
                        <input type="text" name="phone" value="<?= e($cust['phone']) ?>">
                    </div>
                    <div class="form-row">
                        <label>Email</label>
                        <input type="email" name="email" value="<?= e($cust['email']) ?>">
                    </div>
                    <div class="form-row">
                        <label>Alamat</label>
                        <input type="text" name="address" value="<?= e($cust['address']) ?>">
                    </div>
                </div>
                <div class="form-row">
                    <label>Catatan</label>
                    <textarea name="notes"><?= e($cust['notes']) ?></textarea>
                </div>
            </div>
            <div class="modal-foot">
                <a href="<?= url('page=customers') ?>" class="btn btn-ghost">Batal</a>
                <button class="btn" type="submit">Simpan</button>
            </div>
        </form>
    </div>
    <?php
    return;
}

// ---- List ----
$q = str_input('q');
$page = max(1, int_input('p', 1));
$perPage = 10;

$where = '';
$params = [];
if ($q !== '') {
    $where = 'WHERE c.name LIKE ? OR c.phone LIKE ? OR c.code LIKE ?';
    $params = ["%$q%", "%$q%", "%$q%"];
}
$total = (int) Database::scalar("SELECT COUNT(*) FROM customers c $where", $params);
$pg = paginate($total, $page, $perPage);

$rows = Database::all(
    "SELECT c.*,
            (SELECT COUNT(*) FROM pets p WHERE p.customer_id=c.id) AS pet_count,
            (SELECT COUNT(*) FROM transactions t WHERE t.customer_id=c.id) AS trx_count,
            (SELECT COALESCE(SUM(total),0) FROM transactions t WHERE t.customer_id=c.id) AS spent
     FROM customers c $where ORDER BY c.name LIMIT {$pg['perPage']} OFFSET {$pg['offset']}",
    $params
);
?>
<div class="toolbar">
    <form class="search-box" method="get">
        <input type="hidden" name="page" value="customers">
        <input type="text" name="q" placeholder="Cari nama / telepon / kode..." value="<?= e($q) ?>">
    </form>
    <div class="spacer"></div>
    <a href="<?= url('page=customers&action=create') ?>" class="btn">+ Tambah Pelanggan</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead>
                <tr><th>Kode</th><th>Nama</th><th>Telepon</th><th>Hewan</th><th class="num">Transaksi</th><th class="num">Total Belanja</th><th></th></tr>
            </thead>
            <tbody>
            <?php if (!$rows): ?>
                <tr><td colspan="7" class="empty">Tidak ada pelanggan.</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="text-muted"><?= e($r['code']) ?></td>
                    <td class="fw-700"><?= e($r['name']) ?><br><small class="text-muted"><?= e($r['email']) ?></small></td>
                    <td><?= e($r['phone'] ?: '-') ?></td>
                    <td><span class="badge badge-gray"><?= (int) $r['pet_count'] ?> ekor</span></td>
                    <td class="num"><?= (int) $r['trx_count'] ?></td>
                    <td class="num fw-700"><?= money($r['spent']) ?></td>
                    <td>
                        <div class="actions">
                            <a class="icon-btn" href="<?= url('page=pets&customer_id=' . $r['id']) ?>">🐾</a>
                            <a class="icon-btn" href="<?= url('page=customers&action=edit&id=' . $r['id']) ?>">✏️</a>
                            <form method="post" action="<?= url('page=customers&action=delete') ?>" data-confirm="Hapus pelanggan ini beserta hewannya?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button class="icon-btn del" type="submit">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php require VIEW_PATH . '/_pagination.php'; ?>
</div>
