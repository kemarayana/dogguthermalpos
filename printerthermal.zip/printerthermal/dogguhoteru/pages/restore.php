<?php
/** Restore the SQLite database from an uploaded backup file. */
if ((Auth::user()['role'] ?? '') !== 'admin') {
    flash('Hanya admin yang dapat memulihkan database.', 'error');
    redirect('page=settings');
}
if (!is_post() || empty($_FILES['dbfile']['tmp_name'])) {
    flash('Tidak ada file yang diunggah.', 'error');
    redirect('page=settings');
}

$tmp = $_FILES['dbfile']['tmp_name'];

// Basic sanity check: SQLite files start with "SQLite format 3\000".
$header = file_get_contents($tmp, false, null, 0, 16);
if ($header !== "SQLite format 3\0") {
    flash('File tidak valid (bukan database SQLite).', 'error');
    redirect('page=settings');
}

// Release WAL/connection before overwriting.
Database::conn()->exec('PRAGMA wal_checkpoint(TRUNCATE)');
@unlink(DB_FILE . '-wal');
@unlink(DB_FILE . '-shm');

if (move_uploaded_file($tmp, DB_FILE)) {
    log_event('warning', 'Database restored from backup');
    flash('Database berhasil dipulihkan. Silakan login kembali jika diperlukan.');
} else {
    flash('Gagal memulihkan database.', 'error');
}
redirect('page=settings');
