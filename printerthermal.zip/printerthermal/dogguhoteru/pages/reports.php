<?php
/** Sales & operational reports with Excel (CSV) export. */
$pageTitle = 'Laporan';

$from = str_input('from', date('Y-m-01'));
$to = str_input('to', date('Y-m-d'));

// ---- Excel/CSV export (standalone download) ----
if (str_input('action') === 'export') {
    $rows = Database::all(
        "SELECT t.invoice_no, t.created_at, c.name AS customer, s.name AS staff,
                t.payment_method, t.subtotal, t.discount, t.tax, t.total
         FROM transactions t
         LEFT JOIN customers c ON c.id=t.customer_id
         LEFT JOIN staff s ON s.id=t.staff_id
         WHERE date(t.created_at) BETWEEN ? AND ? AND t.status='paid'
         ORDER BY t.created_at",
        [$from, $to]
    );
    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="laporan_penjualan_' . $from . '_' . $to . '.xls"');
    echo "\xEF\xBB\xBF"; // UTF-8 BOM for Excel
    echo "<table border='1'>";
    echo "<tr><th>Invoice</th><th>Tanggal</th><th>Pelanggan</th><th>Kasir</th><th>Metode</th><th>Subtotal</th><th>Diskon</th><th>Pajak</th><th>Total</th></tr>";
    $grand = 0;
    foreach ($rows as $r) {
        $grand += (int) $r['total'];
        echo '<tr>'
            . '<td>' . htmlspecialchars($r['invoice_no']) . '</td>'
            . '<td>' . htmlspecialchars($r['created_at']) . '</td>'
            . '<td>' . htmlspecialchars($r['customer'] ?? 'Umum') . '</td>'
            . '<td>' . htmlspecialchars($r['staff'] ?? '') . '</td>'
            . '<td>' . htmlspecialchars(strtoupper($r['payment_method'])) . '</td>'
            . '<td>' . (int) $r['subtotal'] . '</td>'
            . '<td>' . (int) $r['discount'] . '</td>'
            . '<td>' . (int) $r['tax'] . '</td>'
            . '<td>' . (int) $r['total'] . '</td>'
            . '</tr>';
    }
    echo "<tr><th colspan='8'>TOTAL</th><th>$grand</th></tr>";
    echo '</table>';
    exit;
}

// ---- Metrics ----
$params = [$from, $to];
$summary = Database::one(
    "SELECT COUNT(*) AS trx, COALESCE(SUM(total),0) AS total, COALESCE(SUM(discount),0) AS disc,
            COALESCE(SUM(tax),0) AS tax, COALESCE(AVG(total),0) AS avg
     FROM transactions WHERE date(created_at) BETWEEN ? AND ? AND status='paid'", $params
);

$byCategory = Database::all(
    "SELECT s.category, SUM(ti.qty) AS qty, SUM(ti.line_total) AS revenue
     FROM transaction_items ti
     JOIN transactions t ON t.id=ti.transaction_id
     LEFT JOIN services s ON s.id=ti.service_id
     WHERE date(t.created_at) BETWEEN ? AND ? AND t.status='paid'
     GROUP BY s.category ORDER BY revenue DESC", $params
);

$byMethod = Database::all(
    "SELECT payment_method, COUNT(*) AS cnt, SUM(total) AS revenue
     FROM transactions WHERE date(created_at) BETWEEN ? AND ? AND status='paid'
     GROUP BY payment_method ORDER BY revenue DESC", $params
);

$daily = Database::all(
    "SELECT date(created_at) AS d, COUNT(*) AS cnt, SUM(total) AS revenue
     FROM transactions WHERE date(created_at) BETWEEN ? AND ? AND status='paid'
     GROUP BY date(created_at) ORDER BY d DESC LIMIT 31", $params
);

$topCustomers = Database::all(
    "SELECT c.name, COUNT(t.id) AS trx, SUM(t.total) AS spent
     FROM transactions t JOIN customers c ON c.id=t.customer_id
     WHERE date(t.created_at) BETWEEN ? AND ? AND t.status='paid'
     GROUP BY c.id ORDER BY spent DESC LIMIT 5", $params
);

$topPets = Database::all(
    "SELECT p.name, c.name AS owner, COUNT(t.id) AS visits
     FROM transactions t JOIN pets p ON p.id=t.pet_id JOIN customers c ON c.id=p.customer_id
     WHERE date(t.created_at) BETWEEN ? AND ? AND t.status='paid'
     GROUP BY p.id ORDER BY visits DESC LIMIT 5", $params
);

$maxCat = max(1, (int) max(array_column($byCategory, 'revenue') ?: [1]));
?>
<div class="toolbar">
    <form class="flex" method="get" style="gap:10px; flex-wrap:wrap">
        <input type="hidden" name="page" value="reports">
        <input type="date" name="from" value="<?= e($from) ?>" style="width:auto">
        <span class="text-muted">s/d</span>
        <input type="date" name="to" value="<?= e($to) ?>" style="width:auto">
        <button class="btn btn-ghost btn-sm" type="submit">Terapkan</button>
    </form>
    <div class="spacer"></div>
    <a class="btn btn-success" href="<?= url('page=reports&action=export&from=' . urlencode($from) . '&to=' . urlencode($to)) ?>">⬇️ Export Excel</a>
</div>

<div class="grid grid-4 mb-2">
    <div class="stat"><div class="stat-icon i-green">💰</div><div><div class="stat-label">Total Penjualan</div><div class="stat-value"><?= money($summary['total']) ?></div></div></div>
    <div class="stat"><div class="stat-icon i-blue">🧾</div><div><div class="stat-label">Jumlah Transaksi</div><div class="stat-value"><?= (int) $summary['trx'] ?></div></div></div>
    <div class="stat"><div class="stat-icon i-amber">📊</div><div><div class="stat-label">Rata-rata / Transaksi</div><div class="stat-value"><?= money($summary['avg']) ?></div></div></div>
    <div class="stat"><div class="stat-icon i-cyan">🏷️</div><div><div class="stat-label">Total Pajak</div><div class="stat-value"><?= money($summary['tax']) ?></div></div></div>
</div>

<div class="grid grid-2 mb-2">
    <div class="card">
        <div class="card-head"><h2>Pendapatan per Kategori</h2></div>
        <div class="card-body">
            <?php if (!$byCategory): ?><p class="empty">Tidak ada data.</p><?php endif; ?>
            <?php foreach ($byCategory as $c): ?>
                <div class="mb-2">
                    <div class="flex-between"><span class="fw-700"><?= e($c['category'] ?? 'Lainnya') ?></span><span><?= money($c['revenue']) ?></span></div>
                    <div style="height:8px; background:var(--surface-2); border-radius:6px; margin-top:4px; overflow:hidden">
                        <div style="height:100%; width:<?= (int) round($c['revenue'] / $maxCat * 100) ?>%; background:linear-gradient(90deg,#6366f1,#4f46e5)"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="card">
        <div class="card-head"><h2>Metode Pembayaran</h2></div>
        <div class="table-wrap">
            <table class="tbl">
                <thead><tr><th>Metode</th><th class="num">Transaksi</th><th class="num">Total</th></tr></thead>
                <tbody>
                <?php if (!$byMethod): ?><tr><td colspan="3" class="empty">Tidak ada data.</td></tr><?php endif; ?>
                <?php foreach ($byMethod as $m): ?>
                    <tr><td><span class="badge badge-blue"><?= e(strtoupper($m['payment_method'])) ?></span></td><td class="num"><?= (int) $m['cnt'] ?></td><td class="num fw-700"><?= money($m['revenue']) ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="grid grid-2 mb-2">
    <div class="card">
        <div class="card-head"><h2>Top Pelanggan</h2></div>
        <div class="table-wrap">
            <table class="tbl">
                <thead><tr><th>Pelanggan</th><th class="num">Transaksi</th><th class="num">Belanja</th></tr></thead>
                <tbody>
                <?php if (!$topCustomers): ?><tr><td colspan="3" class="empty">Tidak ada data.</td></tr><?php endif; ?>
                <?php foreach ($topCustomers as $c): ?>
                    <tr><td class="fw-700"><?= e($c['name']) ?></td><td class="num"><?= (int) $c['trx'] ?></td><td class="num fw-700"><?= money($c['spent']) ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card">
        <div class="card-head"><h2>Hewan Paling Sering</h2></div>
        <div class="table-wrap">
            <table class="tbl">
                <thead><tr><th>Hewan</th><th>Pemilik</th><th class="num">Kunjungan</th></tr></thead>
                <tbody>
                <?php if (!$topPets): ?><tr><td colspan="3" class="empty">Tidak ada data.</td></tr><?php endif; ?>
                <?php foreach ($topPets as $p): ?>
                    <tr><td class="fw-700">🐾 <?= e($p['name']) ?></td><td><?= e($p['owner']) ?></td><td class="num"><?= (int) $p['visits'] ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-head"><h2>Rincian Harian</h2></div>
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Tanggal</th><th class="num">Transaksi</th><th class="num">Pendapatan</th></tr></thead>
            <tbody>
            <?php if (!$daily): ?><tr><td colspan="3" class="empty">Tidak ada data pada periode ini.</td></tr><?php endif; ?>
            <?php foreach ($daily as $d): ?>
                <tr><td><?= fdate($d['d']) ?></td><td class="num"><?= (int) $d['cnt'] ?></td><td class="num fw-700"><?= money($d['revenue']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
