<?php
/** Business, tax, printer settings + staff, backup/restore, test print. */
$pageTitle = 'Pengaturan';
$action = str_input('action');
$isAdmin = (Auth::user()['role'] ?? '') === 'admin';

// ---- Backup (download SQLite) ----
if ($action === 'backup') {
    Database::conn()->exec('PRAGMA wal_checkpoint(TRUNCATE)');
    while (ob_get_level() > 0) { ob_end_clean(); }
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="dogguhoteru_backup_' . date('Ymd_His') . '.sqlite"');
    header('Content-Length: ' . filesize(DB_FILE));
    readfile(DB_FILE);
    exit;
}

// ---- Save business/tax/printer settings ----
if (is_post() && $action === 'save') {
    if (!$isAdmin) { flash('Hanya admin.', 'error'); redirect('page=settings'); }
    $keys = ['business_name', 'business_address', 'business_phone', 'business_email',
             'tax_rate', 'tax_enabled', 'printer_name', 'printer_width', 'receipt_footer'];
    foreach ($keys as $k) {
        $v = (string) input($k, '');
        Database::run(
            'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
            [$k, $v]
        );
    }
    flash('Pengaturan disimpan.');
    redirect('page=settings');
}

// ---- Add staff ----
if (is_post() && $action === 'add_staff') {
    if (!$isAdmin) { flash('Hanya admin.', 'error'); redirect('page=settings'); }
    $username = str_input('username');
    $pass = (string) input('password', '');
    if ($username === '' || strlen($pass) < 4) {
        flash('Username wajib & password minimal 4 karakter.', 'error');
        redirect('page=settings');
    }
    try {
        Database::insert('staff', [
            'username' => $username, 'name' => str_input('name', $username),
            'role' => str_input('role', 'cashier'),
            'password_hash' => password_hash($pass, PASSWORD_DEFAULT), 'active' => 1,
        ]);
        flash('Staff ditambahkan.');
    } catch (Throwable $e) {
        flash('Gagal: username mungkin sudah dipakai.', 'error');
    }
    redirect('page=settings');
}

// ---- Toggle staff active ----
if (is_post() && $action === 'toggle_staff') {
    if ($isAdmin && int_input('id') !== Auth::id()) {
        $cur = (int) Database::scalar('SELECT active FROM staff WHERE id=?', [int_input('id')]);
        Database::update('staff', ['active' => $cur ? 0 : 1], ['id' => int_input('id')]);
        flash('Status staff diperbarui.');
    }
    redirect('page=settings');
}

$s = fn ($k, $d = '') => setting($k, $d);
$staff = Database::all('SELECT id, username, name, role, active FROM staff ORDER BY id');
?>
<div class="grid grid-2">
    <div class="card">
        <div class="card-head"><h2>Informasi Bisnis</h2></div>
        <form method="post" action="<?= url('page=settings&action=save') ?>">
            <?= csrf_field() ?>
            <div class="card-body">
                <div class="form-row"><label>Nama Bisnis</label><input type="text" name="business_name" value="<?= e($s('business_name', APP_NAME)) ?>" <?= $isAdmin ? '' : 'disabled' ?>></div>
                <div class="form-row"><label>Alamat</label><input type="text" name="business_address" value="<?= e($s('business_address')) ?>" <?= $isAdmin ? '' : 'disabled' ?>></div>
                <div class="form-grid">
                    <div class="form-row"><label>Telepon</label><input type="text" name="business_phone" value="<?= e($s('business_phone')) ?>" <?= $isAdmin ? '' : 'disabled' ?>></div>
                    <div class="form-row"><label>Email</label><input type="email" name="business_email" value="<?= e($s('business_email')) ?>" <?= $isAdmin ? '' : 'disabled' ?>></div>
                </div>

                <h3 class="mt-2 mb-2">Pajak</h3>
                <div class="form-grid">
                    <div class="form-row"><label>Tarif Pajak (%)</label><input type="number" step="0.1" name="tax_rate" value="<?= e($s('tax_rate', DEFAULT_TAX_RATE)) ?>" <?= $isAdmin ? '' : 'disabled' ?>></div>
                    <div class="form-row"><label>Pajak Default</label>
                        <select name="tax_enabled" <?= $isAdmin ? '' : 'disabled' ?>>
                            <option value="1" <?= $s('tax_enabled', '1') === '1' ? 'selected' : '' ?>>Aktif</option>
                            <option value="0" <?= $s('tax_enabled', '1') === '0' ? 'selected' : '' ?>>Nonaktif</option>
                        </select>
                    </div>
                </div>

                <h3 class="mt-2 mb-2">Printer &amp; Struk</h3>
                <div class="form-grid">
                    <div class="form-row"><label>Nama Printer (Windows)</label><input type="text" name="printer_name" value="<?= e($s('printer_name', PRINTER_NAME)) ?>" <?= $isAdmin ? '' : 'disabled' ?>></div>
                    <div class="form-row"><label>Lebar Kertas</label>
                        <select name="printer_width" <?= $isAdmin ? '' : 'disabled' ?>>
                            <option value="80" <?= (int) $s('printer_width', 80) === 80 ? 'selected' : '' ?>>80 mm</option>
                            <option value="58" <?= (int) $s('printer_width', 80) === 58 ? 'selected' : '' ?>>58 mm</option>
                        </select>
                    </div>
                </div>
                <div class="form-row"><label>Footer Struk</label><input type="text" name="receipt_footer" value="<?= e($s('receipt_footer')) ?>" <?= $isAdmin ? '' : 'disabled' ?>></div>
            </div>
            <?php if ($isAdmin): ?>
            <div class="modal-foot"><button class="btn" type="submit">Simpan Pengaturan</button></div>
            <?php endif; ?>
        </form>
    </div>

    <div>
        <div class="card mb-2">
            <div class="card-head"><h2>Printer</h2></div>
            <div class="card-body">
                <p class="text-muted mb-2">Menggunakan metode ESC/POS via Windows spooler (raw_print.ps1), sama seperti <code>test_print.php</code>. Printer: <strong><?= e($s('printer_name', PRINTER_NAME)) ?></strong></p>
                <button class="btn btn-block" id="testPrintBtn">🖨️ Test Print</button>
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-head"><h2>Backup &amp; Restore</h2></div>
            <div class="card-body">
                <p class="text-muted mb-2">Unduh atau pulihkan seluruh basis data (SQLite).</p>
                <a class="btn btn-success btn-block mb-2" href="<?= url('page=settings&action=backup') ?>">⬇️ Download Backup</a>
                <?php if ($isAdmin): ?>
                <form method="post" enctype="multipart/form-data" action="<?= url('page=restore') ?>" data-confirm="Pulihkan database? Data saat ini akan ditimpa!">
                    <?= csrf_field() ?>
                    <input type="file" name="dbfile" accept=".sqlite" class="mb-2" required>
                    <button class="btn btn-danger btn-block" type="submit">⬆️ Restore dari File</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card mt-2">
    <div class="card-head"><h2>Staff / Pengguna</h2><?php if ($isAdmin): ?><button class="btn btn-sm" data-modal-open="staffModal">+ Tambah Staff</button><?php endif; ?></div>
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Username</th><th>Nama</th><th>Peran</th><th>Status</th><?php if ($isAdmin): ?><th></th><?php endif; ?></tr></thead>
            <tbody>
            <?php foreach ($staff as $u): ?>
                <tr>
                    <td class="fw-700"><?= e($u['username']) ?></td>
                    <td><?= e($u['name']) ?></td>
                    <td><span class="badge badge-blue"><?= e(ucfirst($u['role'])) ?></span></td>
                    <td><?= (int) $u['active'] ? '<span class="badge badge-green">Aktif</span>' : '<span class="badge badge-gray">Nonaktif</span>' ?></td>
                    <?php if ($isAdmin): ?>
                    <td>
                        <?php if ((int) $u['id'] !== Auth::id()): ?>
                        <form method="post" action="<?= url('page=settings&action=toggle_staff') ?>">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                            <button class="icon-btn" type="submit"><?= (int) $u['active'] ? 'Nonaktifkan' : 'Aktifkan' ?></button>
                        </form>
                        <?php else: ?><span class="text-muted">(Anda)</span><?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card mt-2">
    <div class="card-head"><h2>Dokumentasi</h2></div>
    <div class="card-body">
        <p class="text-muted">Panduan instalasi, penggunaan, dan pengembang tersedia di file <code>README.md</code> pada folder aplikasi.</p>
        <ul style="margin-left:18px; color:var(--muted); line-height:1.9">
            <li><strong>Deployment:</strong> letakkan folder di <code>htdocs</code>, buka <code>install.php</code>.</li>
            <li><strong>Login default:</strong> admin / admin123.</li>
            <li><strong>Reset data:</strong> jalankan <code>install.php?fresh=1</code>.</li>
            <li><strong>Printer:</strong> pastikan nama printer Windows cocok dengan pengaturan.</li>
        </ul>
    </div>
</div>

<?php if ($isAdmin): ?>
<div class="modal-overlay" id="staffModal">
    <div class="modal">
        <div class="modal-head"><h3>Tambah Staff</h3><button class="modal-close" data-modal-close>&times;</button></div>
        <form method="post" action="<?= url('page=settings&action=add_staff') ?>">
            <?= csrf_field() ?>
            <div class="modal-body">
                <div class="form-row"><label>Nama</label><input type="text" name="name"></div>
                <div class="form-row"><label>Username <span class="req">*</span></label><input type="text" name="username" required></div>
                <div class="form-row"><label>Password <span class="req">*</span></label><input type="text" name="password" required placeholder="min. 4 karakter"></div>
                <div class="form-row"><label>Peran</label>
                    <select name="role"><option value="cashier">Cashier</option><option value="groomer">Groomer</option><option value="admin">Admin</option></select>
                </div>
            </div>
            <div class="modal-foot"><button type="button" class="btn btn-ghost" data-modal-close>Batal</button><button class="btn" type="submit">Simpan</button></div>
        </form>
    </div>
</div>
<?php endif; ?>

<script>
document.getElementById('testPrintBtn').addEventListener('click', async function () {
    this.disabled = true; this.textContent = 'Mengirim...';
    try {
        const r = await fetch(<?= json_encode(url('page=api')) ?> + '&action=test_print');
        const d = await r.json();
        alert(d.ok ? d.message : ('Gagal: ' + d.error));
    } catch (e) { alert('Printer tidak merespons.'); }
    this.disabled = false; this.textContent = '🖨️ Test Print';
});
</script>
