<?php
/**
 * JSON API endpoint for AJAX calls (autocomplete, save sale, printing).
 * Routed via index.php?page=api&action=...  (auth enforced by index.php)
 */

$action = str_input('action');

switch ($action) {

    // -------- Customer autocomplete --------
    case 'search_customer': {
        $q = str_input('q');
        $rows = Database::all(
            "SELECT id, code, name, phone FROM customers
             WHERE name LIKE ? OR phone LIKE ? OR code LIKE ?
             ORDER BY name LIMIT 8",
            ["%$q%", "%$q%", "%$q%"]
        );
        json_out(['ok' => true, 'items' => $rows]);
    }

    // -------- Pets for a customer --------
    case 'customer_pets': {
        $cid = int_input('customer_id');
        $rows = Database::all('SELECT id, name, species, breed FROM pets WHERE customer_id=? ORDER BY name', [$cid]);
        json_out(['ok' => true, 'items' => $rows]);
    }

    // -------- Service autocomplete --------
    case 'search_service': {
        $q = str_input('q');
        $rows = Database::all(
            "SELECT id, name, category, price, unit FROM services
             WHERE active=1 AND (name LIKE ? OR code LIKE ?)
             ORDER BY name LIMIT 10",
            ["%$q%", "%$q%"]
        );
        json_out(['ok' => true, 'items' => $rows]);
    }

    // -------- Save a sale --------
    case 'save_sale': {
        $payload = json_decode(file_get_contents('php://input'), true);
        if (!is_array($payload)) {
            json_out(['ok' => false, 'error' => 'Payload tidak valid.'], 400);
        }
        $items = $payload['items'] ?? [];
        if (!$items) {
            json_out(['ok' => false, 'error' => 'Keranjang kosong.'], 400);
        }

        $customerId = !empty($payload['customer_id']) ? (int) $payload['customer_id'] : null;
        $petId      = !empty($payload['pet_id']) ? (int) $payload['pet_id'] : null;
        $discount   = max(0, (int) ($payload['discount'] ?? 0));
        $taxRate    = (float) ($payload['tax_rate'] ?? 0);
        $method     = in_array($payload['method'] ?? 'cash', ['cash', 'qris', 'debit', 'credit', 'transfer'], true)
                      ? $payload['method'] : 'cash';
        $paid       = max(0, (int) ($payload['paid'] ?? 0));
        $notes      = trim((string) ($payload['notes'] ?? ''));

        // Recompute totals server-side against the services table (never trust client prices).
        $subtotal = 0;
        $clean = [];
        foreach ($items as $it) {
            $svcId = !empty($it['service_id']) ? (int) $it['service_id'] : null;
            $qty = max(1, (int) ($it['qty'] ?? 1));
            if ($svcId) {
                $svc = Database::one('SELECT name, price FROM services WHERE id=?', [$svcId]);
                if (!$svc) { continue; }
                $name = $svc['name'];
                $price = (int) $svc['price'];
            } else {
                $name = trim((string) ($it['description'] ?? 'Item'));
                $price = max(0, (int) ($it['price'] ?? 0));
            }
            $lineTotal = $price * $qty;
            $subtotal += $lineTotal;
            $clean[] = ['service_id' => $svcId, 'description' => $name, 'qty' => $qty, 'price' => $price, 'line_total' => $lineTotal];
        }
        if (!$clean) {
            json_out(['ok' => false, 'error' => 'Tidak ada item valid.'], 400);
        }

        $discount = min($discount, $subtotal);
        $taxable = $subtotal - $discount;
        $tax = (int) round($taxable * $taxRate / 100);
        $total = $taxable + $tax;
        if ($paid < $total) { $paid = $total; }   // fall back to exact
        $change = $paid - $total;

        try {
            Database::begin();
            $invoiceNo = next_invoice_no();
            $tid = Database::insert('transactions', [
                'invoice_no' => $invoiceNo, 'customer_id' => $customerId, 'pet_id' => $petId,
                'staff_id' => Auth::id(), 'subtotal' => $subtotal, 'discount' => $discount,
                'tax' => $tax, 'total' => $total, 'paid' => $paid, 'change' => $change,
                'payment_method' => $method, 'status' => 'paid', 'notes' => $notes,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            foreach ($clean as $it) {
                $it['transaction_id'] = $tid;
                Database::insert('transaction_items', $it);
            }
            Database::insert('payments', [
                'transaction_id' => $tid, 'amount' => $paid, 'method' => $method,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            Database::commit();
        } catch (Throwable $e) {
            Database::rollback();
            json_out(['ok' => false, 'error' => 'Gagal menyimpan: ' . $e->getMessage()], 500);
        }

        log_event('info', 'Sale saved', ['invoice' => $invoiceNo, 'total' => $total]);
        json_out([
            'ok' => true, 'id' => $tid, 'invoice_no' => $invoiceNo,
            'total' => $total, 'change' => $change,
            'receipt_url' => url('page=receipt&id=' . $tid),
        ]);
    }

    // -------- Print an existing receipt --------
    case 'print_receipt': {
        $id = int_input('id');
        $trx = Database::one(
            "SELECT t.*, c.name AS customer_name, p.name AS pet_name, s.name AS staff_name
             FROM transactions t
             LEFT JOIN customers c ON c.id=t.customer_id
             LEFT JOIN pets p ON p.id=t.pet_id
             LEFT JOIN staff s ON s.id=t.staff_id
             WHERE t.id=?", [$id]
        );
        if (!$trx) { json_out(['ok' => false, 'error' => 'Transaksi tidak ditemukan.'], 404); }
        $items = Database::all('SELECT * FROM transaction_items WHERE transaction_id=?', [$id]);
        try {
            PrinterService::printReceipt($trx, $items);
            json_out(['ok' => true, 'message' => 'Struk terkirim ke printer.']);
        } catch (Throwable $e) {
            json_out(['ok' => false, 'error' => $e->getMessage()], 500);
        }
    }

    // -------- Test print --------
    case 'test_print': {
        try {
            PrinterService::testPrint();
            json_out(['ok' => true, 'message' => 'Test print terkirim.']);
        } catch (Throwable $e) {
            json_out(['ok' => false, 'error' => $e->getMessage()], 500);
        }
    }

    default:
        json_out(['ok' => false, 'error' => 'Unknown action.'], 404);
}
