<?php
/** Dashboard - key metrics + recent activity. */
$pageTitle = 'Dashboard';

$today = date('Y-m-d');
$monthStart = date('Y-m-01');

$salesToday   = (int) Database::scalar("SELECT COALESCE(SUM(total),0) FROM transactions WHERE date(created_at)=? AND status='paid'", [$today]);
$countToday   = (int) Database::scalar("SELECT COUNT(*) FROM transactions WHERE date(created_at)=?", [$today]);
$salesMonth   = (int) Database::scalar("SELECT COALESCE(SUM(total),0) FROM transactions WHERE date(created_at)>=? AND status='paid'", [$monthStart]);
$customers    = (int) Database::scalar('SELECT COUNT(*) FROM customers');
$pets         = (int) Database::scalar('SELECT COUNT(*) FROM pets');
$activeBoard  = (int) Database::scalar("SELECT COUNT(*) FROM boardings WHERE status='checked_in'");
$roomsFree    = (int) Database::scalar("SELECT COUNT(*) FROM rooms WHERE status='available'");
$upcomingGroom= (int) Database::scalar("SELECT COUNT(*) FROM groomings WHERE status='scheduled'");

$recent = Database::all(
    "SELECT t.*, c.name AS customer_name
     FROM transactions t LEFT JOIN customers c ON c.id=t.customer_id
     ORDER BY t.id DESC LIMIT 8"
);

// 7-day sales trend
$trend = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $sum = (int) Database::scalar("SELECT COALESCE(SUM(total),0) FROM transactions WHERE date(created_at)=? AND status='paid'", [$d]);
    $trend[] = ['label' => date('d/m', strtotime($d)), 'value' => $sum];
}
$maxTrend = max(1, max(array_column($trend, 'value')));

$topServices = Database::all(
    "SELECT description, SUM(qty) AS qty, SUM(line_total) AS revenue
     FROM transaction_items GROUP BY description ORDER BY revenue DESC LIMIT 5"
);
?>
<div class="grid grid-4 mb-2">
    <div class="stat">
        <div class="stat-icon i-green">💰</div>
        <div>
            <div class="stat-label">Penjualan Hari Ini</div>
            <div class="stat-value"><?= money($salesToday) ?></div>
        </div>
    </div>
    <div class="stat">
        <div class="stat-icon i-blue">🧾</div>
        <div>
            <div class="stat-label">Transaksi Hari Ini</div>
            <div class="stat-value"><?= $countToday ?></div>
        </div>
    </div>
    <div class="stat">
        <div class="stat-icon i-amber">📅</div>
        <div>
            <div class="stat-label">Penjualan Bulan Ini</div>
            <div class="stat-value"><?= money($salesMonth) ?></div>
        </div>
    </div>
    <div class="stat">
        <div class="stat-icon i-cyan">🏠</div>
        <div>
            <div class="stat-label">Penitipan Aktif</div>
            <div class="stat-value"><?= $activeBoard ?> <small class="text-muted" style="font-size:13px;">/ <?= $roomsFree ?> kamar kosong</small></div>
        </div>
    </div>
</div>

<div class="grid grid-4 mb-2">
    <div class="stat"><div class="stat-icon i-blue">👥</div><div><div class="stat-label">Pelanggan</div><div class="stat-value"><?= $customers ?></div></div></div>
    <div class="stat"><div class="stat-icon i-amber">🐕</div><div><div class="stat-label">Hewan Terdaftar</div><div class="stat-value"><?= $pets ?></div></div></div>
    <div class="stat"><div class="stat-icon i-green">✂️</div><div><div class="stat-label">Grooming Terjadwal</div><div class="stat-value"><?= $upcomingGroom ?></div></div></div>
    <div class="stat">
        <div class="stat-icon i-cyan">➕</div>
        <div style="flex:1">
            <div class="stat-label">Aksi Cepat</div>
            <a href="<?= url('page=pos') ?>" class="btn btn-sm mt-1">Buka Kasir</a>
        </div>
    </div>
</div>

<div class="grid grid-2">
    <div class="card">
        <div class="card-head"><h2>Tren Penjualan (7 hari)</h2></div>
        <div class="card-body">
            <div style="display:flex; align-items:flex-end; gap:14px; height:200px;">
                <?php foreach ($trend as $t): ?>
                    <div style="flex:1; display:flex; flex-direction:column; align-items:center; height:100%; justify-content:flex-end;">
                        <div class="text-muted" style="font-size:11px; margin-bottom:6px;"><?= $t['value'] > 0 ? round($t['value']/1000) . 'k' : '' ?></div>
                        <div title="<?= money($t['value']) ?>" style="width:100%; background:linear-gradient(180deg,#6366f1,#4f46e5); border-radius:6px 6px 0 0; height:<?= max(4, (int) round($t['value']/$maxTrend*160)) ?>px;"></div>
                        <div class="text-muted" style="font-size:11px; margin-top:8px;"><?= e($t['label']) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><h2>Layanan Terlaris</h2></div>
        <div class="card-body">
            <?php if (!$topServices): ?>
                <p class="empty">Belum ada data.</p>
            <?php else: ?>
                <table class="tbl">
                    <thead><tr><th>Layanan</th><th class="num">Qty</th><th class="num">Pendapatan</th></tr></thead>
                    <tbody>
                    <?php foreach ($topServices as $s): ?>
                        <tr>
                            <td><?= e($s['description']) ?></td>
                            <td class="num"><?= (int) $s['qty'] ?></td>
                            <td class="num"><?= money($s['revenue']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card mt-2">
    <div class="card-head">
        <h2>Transaksi Terakhir</h2>
        <a href="<?= url('page=transactions') ?>" class="btn btn-ghost btn-sm">Lihat semua</a>
    </div>
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Invoice</th><th>Pelanggan</th><th>Waktu</th><th>Metode</th><th class="num">Total</th><th></th></tr></thead>
            <tbody>
            <?php if (!$recent): ?>
                <tr><td colspan="6" class="empty">Belum ada transaksi.</td></tr>
            <?php endif; ?>
            <?php foreach ($recent as $r): ?>
                <tr>
                    <td class="fw-700"><?= e($r['invoice_no']) ?></td>
                    <td><?= e($r['customer_name'] ?? 'Umum') ?></td>
                    <td class="nowrap"><?= fdatetime($r['created_at']) ?></td>
                    <td><span class="badge badge-blue"><?= e(strtoupper($r['payment_method'])) ?></span></td>
                    <td class="num fw-700"><?= money($r['total']) ?></td>
                    <td><a class="icon-btn" target="_blank" href="<?= url('page=receipt&id=' . $r['id']) ?>">Struk</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
