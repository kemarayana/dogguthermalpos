<?php
/** Standalone receipt view (thermal preview + A4 invoice + print buttons). */
$id = int_input('id');
$trx = Database::one(
    "SELECT t.*, c.name AS customer_name, c.phone AS customer_phone, c.address AS customer_address,
            p.name AS pet_name, s.name AS staff_name
     FROM transactions t
     LEFT JOIN customers c ON c.id=t.customer_id
     LEFT JOIN pets p ON p.id=t.pet_id
     LEFT JOIN staff s ON s.id=t.staff_id
     WHERE t.id=?", [$id]
);
if (!$trx) {
    http_response_code(404);
    exit('Transaksi tidak ditemukan.');
}
$items = Database::all('SELECT * FROM transaction_items WHERE transaction_id=?', [$id]);
$mode = str_input('mode', 'thermal');   // thermal | a4
$width = (int) setting('printer_width', PRINTER_WIDTH);
$biz = setting('business_name', APP_NAME);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk <?= e($trx['invoice_no']) ?></title>
    <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    <style>
        body { background:#e2e8f0; padding:20px; }
        .receipt-actions { max-width:640px; margin:0 auto 18px; display:flex; gap:10px; justify-content:center; flex-wrap:wrap; }
        .a4 { background:#fff; max-width:640px; margin:0 auto; padding:40px; box-shadow:var(--shadow-lg); }
        .a4 h1 { font-size:24px; } .a4 .muted{color:var(--muted)}
    </style>
</head>
<body>
<div class="receipt-actions no-print">
    <a class="btn btn-ghost" href="<?= url('page=pos') ?>">&laquo; Kasir</a>
    <a class="btn btn-ghost" href="<?= url('page=receipt&id=' . $id . '&mode=' . ($mode === 'a4' ? 'thermal' : 'a4')) ?>"><?= $mode === 'a4' ? 'Lihat Thermal' : 'Lihat A4' ?></a>
    <button class="btn" onclick="window.print()">🖨️ Cetak (Browser)</button>
    <button class="btn btn-success" id="thermalBtn">🧾 Cetak Thermal</button>
</div>

<?php if ($mode === 'a4'): ?>
    <!-- A4 invoice -->
    <div class="a4">
        <div class="flex-between" style="align-items:flex-start">
            <div>
                <h1>🐾 <?= e($biz) ?></h1>
                <div class="muted"><?= e(setting('business_address', '')) ?></div>
                <div class="muted">Telp: <?= e(setting('business_phone', '')) ?></div>
            </div>
            <div class="text-right">
                <h2>INVOICE</h2>
                <div class="fw-700"><?= e($trx['invoice_no']) ?></div>
                <div class="muted"><?= fdatetime($trx['created_at']) ?></div>
            </div>
        </div>
        <hr style="margin:20px 0; border:none; border-top:1px solid var(--border)">
        <div class="flex-between mb-2">
            <div>
                <strong>Kepada:</strong><br>
                <?= e($trx['customer_name'] ?? 'Pelanggan Umum') ?><br>
                <span class="muted"><?= e($trx['customer_phone'] ?? '') ?></span><br>
                <span class="muted"><?= e($trx['customer_address'] ?? '') ?></span>
            </div>
            <div class="text-right">
                <?php if ($trx['pet_name']): ?><strong>Hewan:</strong> <?= e($trx['pet_name']) ?><br><?php endif; ?>
                <strong>Kasir:</strong> <?= e($trx['staff_name'] ?? '-') ?>
            </div>
        </div>
        <table class="tbl">
            <thead><tr><th>Layanan</th><th class="num">Qty</th><th class="num">Harga</th><th class="num">Subtotal</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
                <tr><td><?= e($it['description']) ?></td><td class="num"><?= (int) $it['qty'] ?></td><td class="num"><?= money($it['price']) ?></td><td class="num"><?= money($it['line_total']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div style="max-width:280px; margin-left:auto; margin-top:16px">
            <div class="totals-row"><span>Subtotal</span><strong><?= money($trx['subtotal']) ?></strong></div>
            <?php if ((int) $trx['discount'] > 0): ?><div class="totals-row"><span>Diskon</span><strong>-<?= money($trx['discount']) ?></strong></div><?php endif; ?>
            <?php if ((int) $trx['tax'] > 0): ?><div class="totals-row"><span>Pajak</span><strong><?= money($trx['tax']) ?></strong></div><?php endif; ?>
            <div class="totals-row grand"><span>TOTAL</span><span><?= money($trx['total']) ?></span></div>
            <div class="totals-row"><span>Bayar (<?= e(strtoupper($trx['payment_method'])) ?>)</span><span><?= money($trx['paid']) ?></span></div>
            <div class="totals-row"><span>Kembali</span><span><?= money($trx['change']) ?></span></div>
        </div>
        <p class="text-center muted mt-3"><?= e(setting('receipt_footer', 'Terima kasih!')) ?></p>
    </div>
<?php else: ?>
    <!-- Thermal preview -->
    <div class="receipt <?= $width < 80 ? 'w58' : '' ?>">
        <div class="r-center">
            <div class="r-big">🐾 <?= e($biz) ?></div>
            <div><?= e(setting('business_address', '')) ?></div>
            <div>Telp: <?= e(setting('business_phone', '')) ?></div>
        </div>
        <hr>
        <div class="r-row"><span>Invoice</span><span><?= e($trx['invoice_no']) ?></span></div>
        <div class="r-row"><span>Tanggal</span><span><?= date('d/m/y H:i', strtotime($trx['created_at'])) ?></span></div>
        <div class="r-row"><span>Kasir</span><span><?= e($trx['staff_name'] ?? '-') ?></span></div>
        <div class="r-row"><span>Pelanggan</span><span><?= e($trx['customer_name'] ?? 'Umum') ?></span></div>
        <?php if ($trx['pet_name']): ?><div class="r-row"><span>Hewan</span><span><?= e($trx['pet_name']) ?></span></div><?php endif; ?>
        <hr>
        <?php foreach ($items as $it): ?>
            <div><?= e($it['description']) ?></div>
            <div class="r-row"><span><?= (int) $it['qty'] ?> x <?= number_format($it['price'], 0, ',', '.') ?></span><span><?= number_format($it['line_total'], 0, ',', '.') ?></span></div>
        <?php endforeach; ?>
        <hr>
        <div class="r-row"><span>Subtotal</span><span><?= number_format($trx['subtotal'], 0, ',', '.') ?></span></div>
        <?php if ((int) $trx['discount'] > 0): ?><div class="r-row"><span>Diskon</span><span>-<?= number_format($trx['discount'], 0, ',', '.') ?></span></div><?php endif; ?>
        <?php if ((int) $trx['tax'] > 0): ?><div class="r-row"><span>Pajak</span><span><?= number_format($trx['tax'], 0, ',', '.') ?></span></div><?php endif; ?>
        <div class="r-row r-big"><span>TOTAL</span><span><?= number_format($trx['total'], 0, ',', '.') ?></span></div>
        <div class="r-row"><span>Bayar (<?= e($trx['payment_method']) ?>)</span><span><?= number_format($trx['paid'], 0, ',', '.') ?></span></div>
        <div class="r-row"><span>Kembali</span><span><?= number_format($trx['change'], 0, ',', '.') ?></span></div>
        <hr>
        <div class="r-center"><?= e(setting('receipt_footer', 'Terima kasih!')) ?></div>
    </div>
<?php endif; ?>

<script src="<?= asset('js/app.js') ?>"></script>
<script>
document.getElementById('thermalBtn').addEventListener('click', async function () {
    this.disabled = true; this.textContent = 'Mengirim...';
    try {
        const r = await fetch(<?= json_encode(url('page=api')) ?> + '&action=print_receipt&id=<?= $id ?>');
        const d = await r.json();
        alert(d.ok ? d.message : ('Gagal: ' + d.error));
    } catch (e) { alert('Printer tidak merespons.'); }
    this.disabled = false; this.textContent = '🧾 Cetak Thermal';
});
</script>
</body>
</html>
