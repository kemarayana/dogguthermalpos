<?php
/** Service CRUD across all categories. */
$pageTitle = 'Layanan';
$action = str_input('action', 'list');
$categories = ['Boarding', 'Grooming', 'Bath', 'Spa', 'Medicine', 'Transport', 'Accessories'];

// ---- Save ----
if (is_post() && $action === 'save') {
    $id = int_input('id');
    $name = str_input('name');
    if ($name === '') { flash('Nama layanan wajib diisi.', 'error'); redirect('page=services'); }
    $data = [
        'name'        => $name,
        'category'    => str_input('category', 'Grooming'),
        'price'       => int_input('price'),
        'unit'        => str_input('unit', 'pcs'),
        'description' => str_input('description'),
        'active'      => int_input('active', 1),
    ];
    if ($id) {
        Database::update('services', $data, ['id' => $id]);
        flash('Layanan diperbarui.');
    } else {
        $data['code'] = strtoupper(substr($data['category'], 0, 3)) . '-' . str_pad((string) (((int) Database::scalar('SELECT COALESCE(MAX(id),0) FROM services')) + 1), 3, '0', STR_PAD_LEFT);
        Database::insert('services', $data);
        flash('Layanan ditambahkan.');
    }
    redirect('page=services');
}

// ---- Delete ----
if (is_post() && $action === 'delete') {
    Database::delete('services', ['id' => int_input('id')]);
    flash('Layanan dihapus.');
    redirect('page=services');
}

// ---- Create / Edit ----
if ($action === 'create' || $action === 'edit') {
    $svc = ['id' => 0, 'name' => '', 'category' => 'Grooming', 'price' => 0, 'unit' => 'pcs', 'description' => '', 'active' => 1];
    if ($action === 'edit') {
        $svc = Database::one('SELECT * FROM services WHERE id=?', [int_input('id')]);
        if (!$svc) { flash('Layanan tidak ditemukan.', 'error'); redirect('page=services'); }
    }
    ?>
    <div class="card" style="max-width:680px">
        <div class="card-head"><h2><?= $svc['id'] ? 'Edit' : 'Tambah' ?> Layanan</h2></div>
        <form method="post" action="<?= url('page=services&action=save') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $svc['id'] ?>">
            <div class="card-body">
                <div class="form-row">
                    <label>Nama Layanan <span class="req">*</span></label>
                    <input type="text" name="name" required value="<?= e($svc['name']) ?>">
                </div>
                <div class="form-grid">
                    <div class="form-row">
                        <label>Kategori</label>
                        <select name="category">
                            <?php foreach ($categories as $c): ?><option <?= $svc['category'] === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Harga (Rp) <span class="req">*</span></label>
                        <input type="number" name="price" min="0" required value="<?= (int) $svc['price'] ?>">
                    </div>
                    <div class="form-row">
                        <label>Satuan</label>
                        <input type="text" name="unit" value="<?= e($svc['unit']) ?>" placeholder="ekor, hari, pcs...">
                    </div>
                    <div class="form-row">
                        <label>Status</label>
                        <select name="active">
                            <option value="1" <?= (int) $svc['active'] === 1 ? 'selected' : '' ?>>Aktif</option>
                            <option value="0" <?= (int) $svc['active'] === 0 ? 'selected' : '' ?>>Nonaktif</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label>Deskripsi</label>
                    <textarea name="description"><?= e($svc['description']) ?></textarea>
                </div>
            </div>
            <div class="modal-foot">
                <a href="<?= url('page=services') ?>" class="btn btn-ghost">Batal</a>
                <button class="btn" type="submit">Simpan</button>
            </div>
        </form>
    </div>
    <?php
    return;
}

// ---- List ----
$q = str_input('q');
$cat = str_input('cat');
$conds = [];
$params = [];
if ($q !== '') { $conds[] = '(name LIKE ? OR code LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
if ($cat !== '') { $conds[] = 'category = ?'; $params[] = $cat; }
$where = $conds ? 'WHERE ' . implode(' AND ', $conds) : '';
$rows = Database::all("SELECT * FROM services $where ORDER BY category, name", $params);
?>
<div class="toolbar">
    <form class="search-box" method="get">
        <input type="hidden" name="page" value="services">
        <input type="text" name="q" placeholder="Cari layanan..." value="<?= e($q) ?>">
    </form>
    <form method="get">
        <input type="hidden" name="page" value="services">
        <select name="cat" onchange="this.form.submit()">
            <option value="">Semua Kategori</option>
            <?php foreach ($categories as $c): ?><option value="<?= e($c) ?>" <?= $cat === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
        </select>
    </form>
    <div class="spacer"></div>
    <a href="<?= url('page=services&action=create') ?>" class="btn">+ Tambah Layanan</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Kode</th><th>Nama</th><th>Kategori</th><th class="num">Harga</th><th>Satuan</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="7" class="empty">Tidak ada layanan.</td></tr><?php endif; ?>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="text-muted"><?= e($r['code']) ?></td>
                    <td class="fw-700"><?= e($r['name']) ?></td>
                    <td><span class="badge badge-blue"><?= e($r['category']) ?></span></td>
                    <td class="num fw-700"><?= money($r['price']) ?></td>
                    <td><?= e($r['unit']) ?></td>
                    <td><?= (int) $r['active'] ? '<span class="badge badge-green">Aktif</span>' : '<span class="badge badge-gray">Nonaktif</span>' ?></td>
                    <td>
                        <div class="actions">
                            <a class="icon-btn" href="<?= url('page=services&action=edit&id=' . $r['id']) ?>">✏️</a>
                            <form method="post" action="<?= url('page=services&action=delete') ?>" data-confirm="Hapus layanan ini?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button class="icon-btn del" type="submit">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
