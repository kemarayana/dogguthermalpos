<?php
/** Transaction history with filters. */
$pageTitle = 'Transaksi';

// Void a transaction (admin only)
if (is_post() && str_input('action') === 'void') {
    if ((Auth::user()['role'] ?? '') !== 'admin') {
        flash('Hanya admin yang dapat membatalkan transaksi.', 'error');
    } else {
        Database::update('transactions', ['status' => 'void'], ['id' => int_input('id')]);
        flash('Transaksi dibatalkan.');
    }
    redirect('page=transactions');
}

$q = str_input('q');
$from = str_input('from', date('Y-m-01'));
$to = str_input('to', date('Y-m-d'));
$page = max(1, int_input('p', 1));
$perPage = 15;

$conds = ["date(t.created_at) BETWEEN ? AND ?"];
$params = [$from, $to];
if ($q !== '') {
    $conds[] = '(t.invoice_no LIKE ? OR c.name LIKE ?)';
    $params[] = "%$q%"; $params[] = "%$q%";
}
$where = 'WHERE ' . implode(' AND ', $conds);

$total = (int) Database::scalar("SELECT COUNT(*) FROM transactions t LEFT JOIN customers c ON c.id=t.customer_id $where", $params);
$pg = paginate($total, $page, $perPage);
$sumTotal = (int) Database::scalar("SELECT COALESCE(SUM(t.total),0) FROM transactions t LEFT JOIN customers c ON c.id=t.customer_id $where AND t.status='paid'", $params);

$rows = Database::all(
    "SELECT t.*, c.name AS customer_name, s.name AS staff_name
     FROM transactions t
     LEFT JOIN customers c ON c.id=t.customer_id
     LEFT JOIN staff s ON s.id=t.staff_id
     $where ORDER BY t.id DESC LIMIT {$pg['perPage']} OFFSET {$pg['offset']}",
    $params
);
?>
<div class="toolbar">
    <form class="flex" method="get" style="gap:10px; flex-wrap:wrap">
        <input type="hidden" name="page" value="transactions">
        <div class="search-box"><input type="text" name="q" placeholder="Invoice / pelanggan..." value="<?= e($q) ?>"></div>
        <input type="date" name="from" value="<?= e($from) ?>" style="width:auto">
        <span class="text-muted">s/d</span>
        <input type="date" name="to" value="<?= e($to) ?>" style="width:auto">
        <button class="btn btn-ghost btn-sm" type="submit">Filter</button>
    </form>
    <div class="spacer"></div>
    <span class="badge badge-green big" style="padding:8px 14px">Total: <?= money($sumTotal) ?></span>
</div>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Invoice</th><th>Waktu</th><th>Pelanggan</th><th>Kasir</th><th>Metode</th><th class="num">Total</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="8" class="empty">Tidak ada transaksi pada periode ini.</td></tr><?php endif; ?>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="fw-700"><?= e($r['invoice_no']) ?></td>
                    <td class="nowrap"><?= fdatetime($r['created_at']) ?></td>
                    <td><?= e($r['customer_name'] ?? 'Umum') ?></td>
                    <td><?= e($r['staff_name'] ?? '-') ?></td>
                    <td><span class="badge badge-blue"><?= e(strtoupper($r['payment_method'])) ?></span></td>
                    <td class="num fw-700"><?= money($r['total']) ?></td>
                    <td><?php
                        $st = $r['status'];
                        $cls = $st === 'paid' ? 'badge-green' : ($st === 'void' ? 'badge-red' : 'badge-amber');
                        echo '<span class="badge ' . $cls . '">' . e(strtoupper($st)) . '</span>';
                    ?></td>
                    <td>
                        <div class="actions">
                            <a class="icon-btn" target="_blank" href="<?= url('page=receipt&id=' . $r['id']) ?>">🧾</a>
                            <?php if ($r['status'] === 'paid' && (Auth::user()['role'] ?? '') === 'admin'): ?>
                            <form method="post" action="<?= url('page=transactions&action=void') ?>" data-confirm="Batalkan transaksi ini?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button class="icon-btn del" type="submit">Batal</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php require VIEW_PATH . '/_pagination.php'; ?>
</div>
