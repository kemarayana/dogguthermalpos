<?php
/** Kandang (rooms) CRUD — manage boarding room/kennel inventory. */
$pageTitle = 'Kandang';
$action = str_input('action', 'list');
$types = ['Standard', 'Deluxe', 'VIP'];

// ---- Save ----
if (is_post() && $action === 'save') {
    $id = int_input('id');
    $name = str_input('name');
    if ($name === '') { flash('Nama kandang wajib diisi.', 'error'); redirect('page=rooms'); }
    $data = [
        'name'        => $name,
        'type'        => str_input('type', 'Standard'),
        'daily_price' => int_input('daily_price'),
        'notes'       => str_input('notes'),
    ];
    if ($id) {
        Database::update('rooms', $data, ['id' => $id]);
        flash('Kandang diperbarui.');
    } else {
        $data['status'] = 'available';
        Database::insert('rooms', $data);
        flash('Kandang ditambahkan.');
    }
    redirect('page=rooms');
}

// ---- Delete ----
if (is_post() && $action === 'delete') {
    $id = int_input('id');
    $room = Database::one('SELECT * FROM rooms WHERE id=?', [$id]);
    if ($room && $room['status'] === 'occupied') {
        flash('Kandang sedang terisi, tidak bisa dihapus.', 'error');
        redirect('page=rooms');
    }
    Database::delete('rooms', ['id' => $id]);
    flash('Kandang dihapus.');
    redirect('page=rooms');
}

// ---- Create / Edit ----
if ($action === 'create' || $action === 'edit') {
    $room = ['id' => 0, 'name' => '', 'type' => 'Standard', 'daily_price' => 0, 'notes' => ''];
    if ($action === 'edit') {
        $room = Database::one('SELECT * FROM rooms WHERE id=?', [int_input('id')]);
        if (!$room) { flash('Kandang tidak ditemukan.', 'error'); redirect('page=rooms'); }
    }
    ?>
    <div class="card" style="max-width:680px">
        <div class="card-head"><h2><?= $room['id'] ? 'Edit' : 'Tambah' ?> Kandang</h2></div>
        <form method="post" action="<?= url('page=rooms&action=save') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $room['id'] ?>">
            <div class="card-body">
                <div class="form-row">
                    <label>Nama Kandang <span class="req">*</span></label>
                    <input type="text" name="name" required value="<?= e($room['name']) ?>" placeholder="Kandang A1, Suite VIP 1...">
                </div>
                <div class="form-grid">
                    <div class="form-row">
                        <label>Tipe</label>
                        <select name="type">
                            <?php foreach ($types as $t): ?><option <?= $room['type'] === $t ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-row">
                        <label>Harga per Hari (Rp) <span class="req">*</span></label>
                        <input type="number" name="daily_price" min="0" required value="<?= (int) $room['daily_price'] ?>">
                    </div>
                </div>
                <div class="form-row">
                    <label>Catatan</label>
                    <textarea name="notes" placeholder="Ukuran, lokasi, fasilitas..."><?= e($room['notes']) ?></textarea>
                </div>
            </div>
            <div class="modal-foot">
                <a href="<?= url('page=rooms') ?>" class="btn btn-ghost">Batal</a>
                <button class="btn" type="submit">Simpan</button>
            </div>
        </form>
    </div>
    <?php
    return;
}

// ---- List ----
$rows = Database::all('SELECT * FROM rooms ORDER BY type, name');
$total = count($rows);
$occupied = count(array_filter($rows, fn ($r) => $r['status'] === 'occupied'));
?>
<div class="grid grid-4 mb-2">
    <div class="stat"><div class="stat-icon i-cyan">🏠</div><div><div class="stat-label">Total Kandang</div><div class="stat-value"><?= $total ?></div></div></div>
    <div class="stat"><div class="stat-icon i-amber">🐕</div><div><div class="stat-label">Terisi</div><div class="stat-value"><?= $occupied ?></div></div></div>
    <div class="stat"><div class="stat-icon i-green">✅</div><div><div class="stat-label">Kosong</div><div class="stat-value"><?= $total - $occupied ?></div></div></div>
</div>

<div class="toolbar">
    <div class="spacer"></div>
    <a href="<?= url('page=rooms&action=create') ?>" class="btn">+ Tambah Kandang</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>Nama</th><th>Tipe</th><th class="num">Harga/Hari</th><th>Status</th><th>Catatan</th><th></th></tr></thead>
            <tbody>
            <?php if (!$rows): ?><tr><td colspan="6" class="empty">Belum ada kandang. Tambahkan kandang pertama.</td></tr><?php endif; ?>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="fw-700"><?= e($r['name']) ?></td>
                    <td><span class="badge badge-blue"><?= e($r['type']) ?></span></td>
                    <td class="num fw-700"><?= money($r['daily_price']) ?></td>
                    <td><?= $r['status'] === 'occupied' ? '<span class="badge badge-amber">Terisi</span>' : '<span class="badge badge-green">Kosong</span>' ?></td>
                    <td class="text-muted"><?= e($r['notes'] ?: '-') ?></td>
                    <td>
                        <div class="actions">
                            <a class="icon-btn" href="<?= url('page=rooms&action=edit&id=' . $r['id']) ?>">✏️</a>
                            <form method="post" action="<?= url('page=rooms&action=delete') ?>" data-confirm="Hapus kandang ini?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button class="icon-btn del" type="submit" <?= $r['status'] === 'occupied' ? 'disabled' : '' ?>>🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
