<?php

declare(strict_types=1);

/**
 * Doggu Hoteru POS - global configuration.
 *
 * Adjust the printer name / library paths here if the environment changes.
 */

// ---- Paths -------------------------------------------------------------
define('BASE_PATH', dirname(__DIR__));                 // .../dogguhoteru
define('APP_PATH', BASE_PATH . '/app');
define('VIEW_PATH', BASE_PATH . '/views');
define('PAGE_PATH', BASE_PATH . '/pages');
define('DATA_PATH', BASE_PATH . '/data');
define('UPLOAD_PATH', BASE_PATH . '/uploads');
define('DB_FILE', DATA_PATH . '/pos.sqlite');

// Base URL (folder the app is served from). Auto-detected, override if needed.
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/dogguhoteru'));
define('BASE_URL', rtrim($scriptDir, '/'));

// ---- Printing ----------------------------------------------------------
// The Mike42 escpos-php library and raw_print.ps1 live in the parent folder
// (C:\xampp\htdocs\printerthermal) - reuse the working test_print.php setup.
define('ESCPOS_LIB_DIR', dirname(BASE_PATH));            // .../printerthermal
define('RAW_PRINT_SCRIPT', ESCPOS_LIB_DIR . '/raw_print.ps1');
define('PRINTER_NAME', 'Xprinter XP-80');               // Windows spooler name
define('PRINTER_WIDTH', 80);                            // 58 or 80 (mm)

// ---- Localisation ------------------------------------------------------
define('CURRENCY', 'IDR');
define('CURRENCY_SYMBOL', 'Rp');
define('APP_TIMEZONE', 'Asia/Jakarta');
date_default_timezone_set(APP_TIMEZONE);

// ---- App ---------------------------------------------------------------
define('APP_NAME', 'Doggu Hoteru');
define('APP_TAGLINE', 'Pet Hotel & Grooming POS');
define('DEFAULT_TAX_RATE', 11);                         // % PPN (overridable in settings)

// ---- Error handling ----------------------------------------------------
error_reporting(E_ALL);
ini_set('display_errors', '1');   // dev; set to '0' in production
ini_set('log_errors', '1');
ini_set('error_log', DATA_PATH . '/php-error.log');
