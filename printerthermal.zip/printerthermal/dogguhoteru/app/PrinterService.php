<?php

declare(strict_types=1);

/**
 * PrinterService - builds ESC/POS receipts and sends them to the Windows
 * spooler using the exact working method from test_print.php:
 * Mike42\Escpos + MemoryPrintConnector -> raw_print.ps1 (RAW datatype).
 */
final class PrinterService
{
    private static bool $autoloaderRegistered = false;

    /** Register the Mike42 autoloader against the parent library folder. */
    private static function bootstrap(): void
    {
        if (self::$autoloaderRegistered) {
            return;
        }
        spl_autoload_register(function (string $class): void {
            $prefix = 'Mike42\\Escpos\\';
            if (strncmp($prefix, $class, strlen($prefix)) !== 0) {
                return;
            }
            $relative = substr($class, strlen($prefix));
            $file = ESCPOS_LIB_DIR . DIRECTORY_SEPARATOR
                . str_replace('\\', DIRECTORY_SEPARATOR, $relative) . '.php';
            if (is_file($file)) {
                require $file;
            }
        });
        self::$autoloaderRegistered = true;
    }

    /**
     * Send raw bytes to the printer via the PowerShell spooler helper.
     * Mirrors sendRawToPrinter() in test_print.php.
     */
    private static function sendRaw(string $printerName, string $data): void
    {
        $tempFile = tempnam(sys_get_temp_dir(), 'escpos');
        if ($tempFile === false) {
            throw new RuntimeException('Failed to create temp file for print job.');
        }
        file_put_contents($tempFile, $data);

        $command = sprintf(
            'powershell -NoProfile -ExecutionPolicy Bypass -File %s -PrinterName %s -FilePath %s 2>&1',
            escapeshellarg(RAW_PRINT_SCRIPT),
            escapeshellarg($printerName),
            escapeshellarg($tempFile)
        );

        exec($command, $output, $exitCode);
        @unlink($tempFile);

        if ($exitCode !== 0) {
            throw new RuntimeException('Raw print helper failed: ' . implode("\n", $output));
        }
    }

    /**
     * Print a transaction receipt.
     *
     * @param array $trx    transaction row (with joined customer/pet fields)
     * @param array $items  transaction_items rows
     */
    public static function printReceipt(array $trx, array $items): void
    {
        self::bootstrap();

        $printerName = (string) setting('printer_name', PRINTER_NAME);
        $width = (int) setting('printer_width', PRINTER_WIDTH);
        $cols = $width >= 80 ? 42 : 32;

        $connector = new \Mike42\Escpos\PrintConnectors\MemoryPrintConnector();
        $printer = new \Mike42\Escpos\Printer($connector);

        try {
            $biz = (string) setting('business_name', APP_NAME);
            $addr = (string) setting('business_address', '');
            $phone = (string) setting('business_phone', '');

            // ---- Header ----
            $printer->setJustification(\Mike42\Escpos\Printer::JUSTIFY_CENTER);
            $printer->setEmphasis(true);
            $printer->setTextSize(2, 2);
            $printer->text($biz . "\n");
            $printer->setTextSize(1, 1);
            $printer->setEmphasis(false);
            if ($addr !== '') {
                $printer->text($addr . "\n");
            }
            if ($phone !== '') {
                $printer->text('Telp: ' . $phone . "\n");
            }
            $printer->text(str_repeat('=', $cols) . "\n");

            // ---- Meta ----
            $printer->setJustification(\Mike42\Escpos\Printer::JUSTIFY_LEFT);
            $printer->text(self::line('Invoice', $trx['invoice_no'], $cols));
            $printer->text(self::line('Tanggal', date('d/m/Y H:i', strtotime($trx['created_at'])), $cols));
            $printer->text(self::line('Kasir', $trx['staff_name'] ?? '-', $cols));
            $printer->text(self::line('Pelanggan', $trx['customer_name'] ?? 'Umum', $cols));
            if (!empty($trx['pet_name'])) {
                $printer->text(self::line('Hewan', $trx['pet_name'], $cols));
            }
            $printer->text(str_repeat('-', $cols) . "\n");

            // ---- Items ----
            foreach ($items as $it) {
                $name = $it['description'];
                $qty = (int) $it['qty'];
                $price = (int) $it['price'];
                $lineTotal = (int) $it['line_total'];
                $printer->text($name . "\n");
                $detail = sprintf('  %d x %s', $qty, number_format($price, 0, ',', '.'));
                $printer->text(self::line($detail, number_format($lineTotal, 0, ',', '.'), $cols));
            }
            $printer->text(str_repeat('-', $cols) . "\n");

            // ---- Totals ----
            $printer->text(self::line('Subtotal', number_format((int) $trx['subtotal'], 0, ',', '.'), $cols));
            if ((int) $trx['discount'] > 0) {
                $printer->text(self::line('Diskon', '-' . number_format((int) $trx['discount'], 0, ',', '.'), $cols));
            }
            if ((int) $trx['tax'] > 0) {
                $printer->text(self::line('Pajak', number_format((int) $trx['tax'], 0, ',', '.'), $cols));
            }
            $printer->setEmphasis(true);
            $printer->text(self::line('TOTAL', 'Rp ' . number_format((int) $trx['total'], 0, ',', '.'), $cols));
            $printer->setEmphasis(false);
            $printer->text(self::line('Bayar (' . ($trx['payment_method'] ?? 'cash') . ')', number_format((int) $trx['paid'], 0, ',', '.'), $cols));
            $printer->text(self::line('Kembali', number_format((int) $trx['change'], 0, ',', '.'), $cols));

            $printer->text(str_repeat('=', $cols) . "\n");

            // ---- Footer ----
            $printer->setJustification(\Mike42\Escpos\Printer::JUSTIFY_CENTER);
            $footer = (string) setting('receipt_footer', 'Terima kasih atas kunjungan Anda!');
            $printer->text($footer . "\n");
            $printer->feed(2);
            $printer->cut();

            $data = $connector->getData();
            $printer->close();

            self::sendRaw($printerName, $data);
        } catch (Throwable $e) {
            // Ensure connector is released even on failure.
            try {
                $printer->close();
            } catch (Throwable $ignored) {
            }
            throw $e;
        }
    }

    /** Fire the built-in test print (same content as test_print.php). */
    public static function testPrint(): void
    {
        self::bootstrap();
        $printerName = (string) setting('printer_name', PRINTER_NAME);

        $connector = new \Mike42\Escpos\PrintConnectors\MemoryPrintConnector();
        $printer = new \Mike42\Escpos\Printer($connector);

        $printer->setJustification(\Mike42\Escpos\Printer::JUSTIFY_CENTER);
        $printer->setEmphasis(true);
        $printer->text("TEST PRINT\n");
        $printer->setEmphasis(false);
        $printer->text(APP_NAME . " POS\n");
        $printer->text(date('Y-m-d H:i:s') . "\n");
        $printer->feed();
        $printer->setJustification(\Mike42\Escpos\Printer::JUSTIFY_LEFT);
        $printer->text("Printer connection is working.\n");
        $printer->feed(2);
        $printer->cut();

        $data = $connector->getData();
        $printer->close();
        self::sendRaw($printerName, $data);
    }

    /** Left label + right value padded to $cols columns. */
    private static function line(string $left, string $right, int $cols): string
    {
        $space = $cols - mb_strlen($left) - mb_strlen($right);
        if ($space < 1) {
            $space = 1;
        }
        return $left . str_repeat(' ', $space) . $right . "\n";
    }
}
