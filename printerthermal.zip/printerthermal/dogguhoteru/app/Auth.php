<?php

declare(strict_types=1);

/**
 * Session-based authentication against the staff table.
 */
final class Auth
{
    public static function attempt(string $username, string $password): bool
    {
        $user = Database::one(
            'SELECT * FROM staff WHERE username = ? AND active = 1',
            [$username]
        );
        if (!$user || !password_verify($password, $user['password_hash'])) {
            return false;
        }
        $_SESSION['user'] = [
            'id'       => (int) $user['id'],
            'username' => $user['username'],
            'name'     => $user['name'],
            'role'     => $user['role'],
        ];
        session_regenerate_id(true);
        // session_regenerate_id wipes nothing but the id; re-set user just in case.
        $_SESSION['user'] = [
            'id'       => (int) $user['id'],
            'username' => $user['username'],
            'name'     => $user['name'],
            'role'     => $user['role'],
        ];
        log_event('info', 'Login', ['user' => $user['username']]);
        return true;
    }

    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    public static function check(): bool
    {
        return isset($_SESSION['user']);
    }

    public static function user(): ?array
    {
        return $_SESSION['user'] ?? null;
    }

    public static function id(): int
    {
        return (int) ($_SESSION['user']['id'] ?? 0);
    }

    public static function require(): void
    {
        if (!self::check()) {
            redirect('page=login');
        }
    }
}
