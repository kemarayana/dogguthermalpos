<?php

declare(strict_types=1);

/**
 * Thin PDO/SQLite database abstraction.
 *
 * Usage:
 *   $db = Database::conn();
 *   $rows = Database::all("SELECT * FROM customers WHERE name LIKE ?", ["%doggu%"]);
 */
final class Database
{
    private static ?PDO $pdo = null;

    public static function conn(): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        if (!is_dir(DATA_PATH)) {
            mkdir(DATA_PATH, 0777, true);
        }

        $pdo = new PDO('sqlite:' . DB_FILE, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec('PRAGMA foreign_keys = ON');
        $pdo->exec('PRAGMA journal_mode = WAL');

        self::$pdo = $pdo;
        return $pdo;
    }

    /** Run a prepared statement and return the PDOStatement. */
    public static function run(string $sql, array $params = []): PDOStatement
    {
        $stmt = self::conn()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /** Fetch all rows. */
    public static function all(string $sql, array $params = []): array
    {
        return self::run($sql, $params)->fetchAll();
    }

    /** Fetch a single row (or null). */
    public static function one(string $sql, array $params = []): ?array
    {
        $row = self::run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    /** Fetch a single scalar value. */
    public static function scalar(string $sql, array $params = [])
    {
        return self::run($sql, $params)->fetchColumn();
    }

    /** Insert a row into $table from an associative array; returns new id. */
    public static function insert(string $table, array $data): int
    {
        $cols = array_keys($data);
        $place = implode(', ', array_map(fn ($c) => ':' . $c, $cols));
        $sql = sprintf(
            'INSERT INTO %s (%s) VALUES (%s)',
            $table,
            implode(', ', $cols),
            $place
        );
        self::run($sql, self::bindable($data));
        return (int) self::conn()->lastInsertId();
    }

    /** Update rows in $table matching $where (assoc). Returns affected rows. */
    public static function update(string $table, array $data, array $where): int
    {
        $set = implode(', ', array_map(fn ($c) => "$c = :$c", array_keys($data)));
        $cond = implode(' AND ', array_map(fn ($c) => "$c = :w_$c", array_keys($where)));
        $params = self::bindable($data);
        foreach ($where as $k => $v) {
            $params['w_' . $k] = $v;
        }
        return self::run("UPDATE $table SET $set WHERE $cond", $params)->rowCount();
    }

    /** Delete rows from $table matching $where (assoc). Returns affected rows. */
    public static function delete(string $table, array $where): int
    {
        $cond = implode(' AND ', array_map(fn ($c) => "$c = :$c", array_keys($where)));
        return self::run("DELETE FROM $table WHERE $cond", self::bindable($where))->rowCount();
    }

    public static function begin(): void
    {
        self::conn()->beginTransaction();
    }

    public static function commit(): void
    {
        self::conn()->commit();
    }

    public static function rollback(): void
    {
        if (self::conn()->inTransaction()) {
            self::conn()->rollBack();
        }
    }

    /** Coerce booleans to ints so SQLite stores them cleanly. */
    private static function bindable(array $data): array
    {
        foreach ($data as $k => $v) {
            if (is_bool($v)) {
                $data[$k] = $v ? 1 : 0;
            }
        }
        return $data;
    }
}
