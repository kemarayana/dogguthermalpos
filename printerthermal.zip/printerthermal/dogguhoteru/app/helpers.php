<?php

declare(strict_types=1);

/**
 * Global helper functions shared across pages and views.
 */

/** HTML-escape a value for safe output. */
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/** Format an integer rupiah amount as "Rp 1.250.000". */
function money($amount): string
{
    return CURRENCY_SYMBOL . ' ' . number_format((float) $amount, 0, ',', '.');
}

/** Build an app URL from a route/page. */
function url(string $path = ''): string
{
    $path = ltrim($path, '/');
    return BASE_URL . '/index.php' . ($path !== '' ? '?' . $path : '');
}

/** Build an asset URL. */
function asset(string $path): string
{
    return BASE_URL . '/assets/' . ltrim($path, '/');
}

/** Redirect to a route and stop execution. */
function redirect(string $query = ''): void
{
    $target = $query === '' ? BASE_URL . '/index.php' : url($query);
    header('Location: ' . $target);
    exit;
}

/** Read a GET/POST value with a default. */
function input(string $key, $default = null)
{
    return $_POST[$key] ?? $_GET[$key] ?? $default;
}

/** Read + trim a string input. */
function str_input(string $key, string $default = ''): string
{
    return trim((string) ($_POST[$key] ?? $_GET[$key] ?? $default));
}

/** Read an integer input. */
function int_input(string $key, int $default = 0): int
{
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    return (int) $v;
}

/** Is this request a POST? */
function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

/** Emit a JSON response and stop. */
function json_out($data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Flash message helpers (one-shot, survive one redirect). */
function flash(string $message, string $type = 'success'): void
{
    $_SESSION['_flash'][] = ['message' => $message, 'type' => $type];
}

function take_flashes(): array
{
    $flashes = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $flashes;
}

/** CSRF token management. */
function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . csrf_token() . '">';
}

function csrf_check(): void
{
    if (!is_post()) {
        return;
    }
    // Accept the token from the form field or the X-CSRF-Token header (AJAX/JSON).
    $token = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        exit('Invalid CSRF token. Please reload the page and try again.');
    }
}

/** A read-only setting fetched from the settings table (cached per request). */
function setting(string $key, $default = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (Database::all('SELECT key, value FROM settings') as $row) {
            $cache[$row['key']] = $row['value'];
        }
    }
    return $cache[$key] ?? $default;
}

/** Generate a sequential invoice number: INV-YYYYMMDD-#### */
function next_invoice_no(): string
{
    $prefix = 'INV-' . date('Ymd') . '-';
    $last = Database::scalar(
        "SELECT invoice_no FROM transactions WHERE invoice_no LIKE ? ORDER BY id DESC LIMIT 1",
        [$prefix . '%']
    );
    $seq = 1;
    if ($last) {
        $seq = ((int) substr((string) $last, -4)) + 1;
    }
    return $prefix . str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
}

/** Write a log entry to the logs table. */
function log_event(string $level, string $message, $context = null): void
{
    try {
        Database::insert('logs', [
            'level'      => $level,
            'message'    => $message,
            'context'    => $context !== null ? json_encode($context) : null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    } catch (Throwable $e) {
        error_log('log_event failed: ' . $e->getMessage());
    }
}

/** Human friendly date. */
function fdate($value, string $format = 'd M Y'): string
{
    if (empty($value)) {
        return '-';
    }
    $ts = is_numeric($value) ? (int) $value : strtotime((string) $value);
    return $ts ? date($format, $ts) : '-';
}

function fdatetime($value): string
{
    return fdate($value, 'd M Y H:i');
}

/** Simple pagination link builder. */
function paginate(int $total, int $page, int $perPage): array
{
    $pages = max(1, (int) ceil($total / $perPage));
    $page = max(1, min($page, $pages));
    return [
        'page'    => $page,
        'pages'   => $pages,
        'total'   => $total,
        'offset'  => ($page - 1) * $perPage,
        'perPage' => $perPage,
    ];
}
