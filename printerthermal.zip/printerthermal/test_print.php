<?php

declare(strict_types=1);

/**
 * Test print script for escpos-php.
 *
 * The printer is a USB thermal printer (Xprinter XP-80, port USB001) whose
 * vendor driver owns the port - writing raw bytes straight to "LPT1" or
 * "USB001" gets silently swallowed. Bytes must instead go through the
 * Windows print spooler using the RAW datatype, which is what raw_print.ps1
 * does via the winspool.drv WritePrinter API.
 *
 * Run with: php test_print.php
 */

const PRINTER_NAME = "Xprinter XP-80";

spl_autoload_register(function (string $class): void {
    $prefix = 'Mike42\\Escpos\\';
    if (strncmp($prefix, $class, strlen($prefix)) !== 0) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = __DIR__ . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $relative) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\MemoryPrintConnector;

function sendRawToPrinter(string $printerName, string $data): void
{
    $tempFile = tempnam(sys_get_temp_dir(), "escpos");
    if ($tempFile === false) {
        throw new RuntimeException("Failed to create temp file for print job.");
    }
    file_put_contents($tempFile, $data);

    $script = escapeshellarg(__DIR__ . DIRECTORY_SEPARATOR . "raw_print.ps1");
    $command = sprintf(
        'powershell -NoProfile -ExecutionPolicy Bypass -File %s -PrinterName %s -FilePath %s 2>&1',
        $script,
        escapeshellarg($printerName),
        escapeshellarg($tempFile)
    );

    exec($command, $output, $exitCode);
    unlink($tempFile);

    if ($exitCode !== 0) {
        throw new RuntimeException("Raw print helper failed: " . implode("\n", $output));
    }
}

try {
    $connector = new MemoryPrintConnector();
    $printer = new Printer($connector);

    $printer->setJustification(Printer::JUSTIFY_CENTER);
    $printer->setEmphasis(true);
    $printer->text("TEST PRINT\n");
    $printer->setEmphasis(false);
    $printer->text("escpos-php via Windows spooler\n");
    $printer->text(date("Y-m-d H:i:s") . "\n");
    $printer->feed();

    $printer->setJustification(Printer::JUSTIFY_LEFT);
    $printer->text("If you can read this, raw ESC/POS\n");
    $printer->text("printing to the USB printer works.\n");
    $printer->feed(2);

    $printer->cut();

    $data = $connector->getData();
    $printer->close();

    sendRawToPrinter(PRINTER_NAME, $data);

    echo "Test print sent successfully.\n";
} catch (Throwable $e) {
    $message = "Print failed: " . $e->getMessage() . "\n";
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, $message);
        exit(1);
    }
    http_response_code(500);
    echo $message;
}
